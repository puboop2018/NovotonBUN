<?php
/**
 * Novoton Booking Service
 * 
 * Handles booking creation, cart operations, and order processing.
 * Extracted from novoton_booking.php for better maintainability.
 * 
 * @package NovotonHolidays
 * @since 2.7.0
 */

namespace Tygh\Addons\NovotonHolidays\Services;

use Tygh\Registry;
use Tygh\Tygh;

class BookingService
{
    /** @var \Tygh\Addons\NovotonHolidays\NovotonApi */
    private $api;
    
    /** @var GuestDataService */
    private $guestService;
    
    /** @var PriceService */
    private $priceService;
    
    /** @var bool */
    private $debug = false;
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->api = fn_novoton_get_api();
        $this->guestService = new GuestDataService();
        $this->priceService = new PriceService();
        $this->debug = (Registry::get('addons.novoton_holidays.debug_logging') ?? 'N') === 'Y';
    }
    
    /**
     * Create a new booking record
     * 
     * @param array $bookingData Booking data from form
     * @param int $product_id Associated product ID
     * @return int Booking ID
     */
    public function createBooking(array $bookingData, int $product_id): int
    {
        // Get current user/session
        $auth = Tygh::$app['session']['auth'] ?? [];
        $user_id = !empty($auth['user_id']) ? intval($auth['user_id']) : 0;
        $session_id = session_id();
        
        // Parse and validate data
        $rooms_data = $this->parseRoomsData($bookingData);
        $guests_data = $this->guestService->parseGuestsData($bookingData);
        
        // Extract room info for database columns
        $room_info = $this->extractRoomInfo($rooms_data, $bookingData);
        
        // Calculate totals
        $totals = $this->calculateTotals($rooms_data);
        
        // Get hotel info
        $hotel_info = fn_novoton_get_hotel_data($bookingData['hotel_id']);
        
        // Build booking record
        $booking_record = [
            'order_id' => 0, // Updated when order is placed
            'user_id' => $user_id,
            'session_id' => $session_id,
            'product_id' => $product_id,
            'hotel_id' => $bookingData['hotel_id'],
            'hotel_name' => $hotel_info['hotel_name'] ?? '',
            'package_name' => $bookingData['package_name'] ?? '',
            'room_id' => $room_info['room_id'],
            'room_type' => $room_info['room_type'],
            'board_id' => $bookingData['board_id'] ?? 'BB',
            'check_in' => $bookingData['check_in'],
            'check_out' => $bookingData['check_out'],
            'nights' => $this->calculateNights($bookingData['check_in'], $bookingData['check_out']),
            'adults' => $totals['adults'],
            'children' => $totals['children'],
            'children_ages' => implode(',', $totals['ages']),
            'num_rooms' => count($rooms_data),
            'rooms_data' => json_encode($rooms_data),
            'guest_name' => $this->guestService->buildGuestList($guests_data),
            'holder_name' => $this->guestService->getHolderName($guests_data, $bookingData),
            'guest_email' => '',
            'guest_phone' => $bookingData['phone'] ?? '',
            'guests_data' => json_encode($guests_data),
            'total_price' => floatval($bookingData['total_price'] ?? 0),
            'currency' => 'EUR',
            'status' => 'pending',
            'special_requests' => $bookingData['special_requests'] ?? '',
            'notes' => $bookingData['special_requests'] ?? '',
        ];
        
        // Check for duplicate booking
        $existing_id = $this->findDuplicateBooking($booking_record);
        
        if ($existing_id) {
            // Update existing
            $this->updateBooking($existing_id, $booking_record);
            return $existing_id;
        }
        
        // Create new
        $booking_id = db_query("INSERT INTO ?:novoton_bookings ?e", $booking_record);
        
        $this->log('Booking created', [
            'booking_id' => $booking_id,
            'hotel_id' => $bookingData['hotel_id'],
            'rooms' => count($rooms_data)
        ]);
        
        return $booking_id;
    }
    
    /**
     * Update existing booking
     * 
     * @param int $booking_id Booking ID
     * @param array $data Data to update
     * @return bool Success
     */
    public function updateBooking(int $booking_id, array $data): bool
    {
        // Remove fields that shouldn't be updated
        unset($data['booking_id'], $data['created_at']);
        
        $result = db_query(
            "UPDATE ?:novoton_bookings SET ?u WHERE booking_id = ?i",
            $data,
            $booking_id
        );
        
        $this->log('Booking updated', ['booking_id' => $booking_id]);
        
        return $result > 0;
    }
    
    /**
     * Get booking by ID
     * 
     * @param int $booking_id Booking ID
     * @return array|null Booking data
     */
    public function getBooking(int $booking_id): ?array
    {
        $booking = db_get_row(
            "SELECT * FROM ?:novoton_bookings WHERE booking_id = ?i",
            $booking_id
        );
        
        if ($booking) {
            // Parse JSON fields
            $booking['rooms_data_parsed'] = json_decode($booking['rooms_data'] ?? '[]', true);
            $booking['guests_data_parsed'] = json_decode($booking['guests_data'] ?? '[]', true);
        }
        
        return $booking ?: null;
    }
    
    /**
     * Get bookings for order
     * 
     * @param int $order_id Order ID
     * @return array Bookings
     */
    public function getBookingsForOrder(int $order_id): array
    {
        return db_get_array(
            "SELECT * FROM ?:novoton_bookings WHERE order_id = ?i ORDER BY booking_id",
            $order_id
        );
    }
    
    /**
     * Link booking to order
     * 
     * @param int $booking_id Booking ID
     * @param int $order_id Order ID
     * @return bool Success
     */
    public function linkToOrder(int $booking_id, int $order_id): bool
    {
        // Get order info for user/email
        $order_info = fn_get_order_info($order_id);
        
        $update = [
            'order_id' => $order_id,
            'user_id' => intval($order_info['user_id'] ?? 0),
            'guest_email' => $order_info['email'] ?? '',
        ];
        
        return $this->updateBooking($booking_id, $update);
    }
    
    /**
     * Add booking to cart
     * 
     * @param int $booking_id Booking ID
     * @param int $product_id Product ID
     * @param array $bookingData Additional booking data
     * @return bool Success
     */
    public function addToCart(int $booking_id, int $product_id, array $bookingData): bool
    {
        $booking = $this->getBooking($booking_id);
        if (!$booking) {
            return false;
        }
        
        // Build cart product
        $product = [
            'product_id' => $product_id,
            'amount' => 1,
            'extra' => $this->buildCartExtra($booking, $bookingData),
        ];
        
        // Add to cart
        $cart = &Tygh::$app['session']['cart'];
        $auth = &Tygh::$app['session']['auth'];
        
        fn_add_product_to_cart($product, $cart, $auth);
        fn_save_cart_content($cart, $auth['user_id'] ?? 0);
        
        // Calculate cart
        fn_calculate_cart_content($cart, $auth, 'S', true, 'F', true);
        
        $this->log('Added to cart', [
            'booking_id' => $booking_id,
            'product_id' => $product_id
        ]);
        
        return true;
    }
    
    /**
     * Build cart extra data
     * 
     * @param array $booking Booking record
     * @param array $bookingData Additional data
     * @return array Cart extra
     */
    private function buildCartExtra(array $booking, array $bookingData): array
    {
        return [
            'novoton_booking' => true,
            'novoton_booking_id' => $booking['booking_id'],
            'hotel_id' => $booking['hotel_id'],
            'hotel_name' => $booking['hotel_name'],
            'hotel_city' => $bookingData['hotel_city'] ?? '',
            'hotel_country' => $bookingData['hotel_country'] ?? 'BULGARIA',
            'package_name' => $booking['package_name'],
            'room_id' => $booking['room_id'],
            'room_name' => str_replace(['%2b', '%2B'], '+', $booking['room_id']),
            'room_type_display' => $booking['room_type'],
            'board_id' => $booking['board_id'],
            'board_name' => $this->getBoardName($booking['board_id']),
            'check_in' => $booking['check_in'],
            'check_out' => $booking['check_out'],
            'nights' => $booking['nights'],
            'adults' => $booking['adults'],
            'children' => $booking['children'],
            'children_ages' => $booking['children_ages'],
            'num_rooms' => $booking['num_rooms'],
            'rooms_data' => $booking['rooms_data'],
            'holder_name' => $booking['holder_name'],
            'guest_name' => $booking['guest_name'],
            'guests_data' => $booking['guests_data'],
            'total_price' => $booking['total_price'],
            'special_requests' => $booking['special_requests'],
            'terms_of_payment' => $bookingData['terms_of_payment'] ?? '',
            'terms_of_cancellation' => $bookingData['terms_of_cancellation'] ?? '',
        ];
    }
    
    /**
     * Parse rooms data from booking form
     * 
     * @param array $bookingData Form data
     * @return array Parsed rooms data
     */
    public function parseRoomsData(array $bookingData): array
    {
        $rooms_data = [];
        
        if (!empty($bookingData['rooms_data'])) {
            $rooms_data = is_string($bookingData['rooms_data'])
                ? json_decode($bookingData['rooms_data'], true)
                : $bookingData['rooms_data'];
        }
        
        // Create default room if empty
        if (empty($rooms_data) || !is_array($rooms_data)) {
            $rooms_data = [[
                'room_id' => $bookingData['room_id'] ?? '',
                'room_name' => fn_novoton_format_room_type($bookingData['room_id'] ?? ''),
                'board_id' => $bookingData['board_id'] ?? 'BB',
                'adults' => intval($bookingData['adults'] ?? 2),
                'children' => intval($bookingData['children'] ?? 0),
                'childrenAges' => $this->parseChildrenAges($bookingData),
                'price' => floatval($bookingData['total_price'] ?? 0),
            ]];
        }
        
        return $rooms_data;
    }
    
    /**
     * Extract room info for database columns
     * 
     * @param array $rooms_data Rooms data
     * @param array $bookingData Booking data fallback
     * @return array Room info [room_id, room_type]
     */
    private function extractRoomInfo(array $rooms_data, array $bookingData): array
    {
        $room_ids = [];
        $room_types = [];
        
        foreach ($rooms_data as $room) {
            if (!empty($room['room_id'])) {
                $room_ids[] = $room['room_id'];
            }
            if (!empty($room['room_name'])) {
                $room_types[] = $room['room_name'];
            } elseif (!empty($room['room_type_display'])) {
                $room_types[] = $room['room_type_display'];
            } elseif (!empty($room['room_id'])) {
                $room_types[] = fn_novoton_format_room_type($room['room_id']);
            }
        }
        
        // Fallback to bookingData
        if (empty($room_ids) && !empty($bookingData['room_id'])) {
            $room_ids[] = $bookingData['room_id'];
            $room_types[] = fn_novoton_format_room_type($bookingData['room_id']);
        }
        
        return [
            'room_id' => implode(', ', $room_ids),
            'room_type' => implode(', ', $room_types),
        ];
    }
    
    /**
     * Calculate totals from rooms data
     * 
     * @param array $rooms_data Rooms data
     * @return array Totals [adults, children, ages, price]
     */
    private function calculateTotals(array $rooms_data): array
    {
        $totals = [
            'adults' => 0,
            'children' => 0,
            'ages' => [],
            'price' => 0,
        ];
        
        foreach ($rooms_data as $room) {
            $totals['adults'] += intval($room['adults'] ?? 0);
            $totals['children'] += intval($room['children'] ?? 0);
            $totals['price'] += floatval($room['price'] ?? 0);
            
            if (!empty($room['childrenAges'])) {
                foreach ($room['childrenAges'] as $age) {
                    if ($age !== null && $age !== 'age_needed') {
                        $totals['ages'][] = intval($age);
                    }
                }
            }
        }
        
        return $totals;
    }
    
    /**
     * Parse children ages from booking data
     * 
     * @param array $bookingData Booking data
     * @return array Ages
     */
    private function parseChildrenAges(array $bookingData): array
    {
        $ages = [];
        
        if (!empty($bookingData['children_ages'])) {
            if (is_string($bookingData['children_ages'])) {
                $ages = array_map('intval', array_filter(
                    explode(',', $bookingData['children_ages']),
                    function($v) { return $v !== ''; }
                ));
            } else {
                $ages = (array)$bookingData['children_ages'];
            }
        }
        
        return $ages;
    }
    
    /**
     * Calculate nights between dates
     * 
     * @param string $check_in Check-in date
     * @param string $check_out Check-out date
     * @return int Number of nights
     */
    public function calculateNights(string $check_in, string $check_out): int
    {
        $in = strtotime($check_in);
        $out = strtotime($check_out);
        
        if (!$in || !$out || $out <= $in) {
            return 0;
        }
        
        return (int)(($out - $in) / 86400);
    }
    
    /**
     * Find duplicate pending booking
     * 
     * @param array $booking_record Booking data
     * @return int|null Existing booking ID or null
     */
    private function findDuplicateBooking(array $booking_record): ?int
    {
        $existing = db_get_field(
            "SELECT booking_id FROM ?:novoton_bookings 
             WHERE order_id = 0 
             AND hotel_id = ?s 
             AND check_in = ?s 
             AND check_out = ?s 
             AND holder_name = ?s
             AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
             LIMIT 1",
            $booking_record['hotel_id'],
            $booking_record['check_in'],
            $booking_record['check_out'],
            $booking_record['holder_name']
        );
        
        return $existing ? intval($existing) : null;
    }
    
    /**
     * Get board name from ID
     * 
     * @param string $board_id Board ID
     * @return string Board name
     */
    private function getBoardName(string $board_id): string
    {
        $map = [
            'AI' => 'All Inclusive',
            'ALL INCL' => 'All Inclusive',
            'UAI' => 'Ultra All Inclusive',
            'FB' => 'Full Board',
            'HB' => 'Half Board',
            'BB' => 'Bed & Breakfast',
            'RO' => 'Room Only',
        ];
        
        return $map[strtoupper($board_id)] ?? $board_id;
    }
    
    /**
     * Log debug message
     * 
     * @param string $message Message
     * @param array $context Context
     */
    private function log(string $message, array $context = []): void
    {
        if ($this->debug) {
            fn_log_event('general', 'runtime', array_merge(
                ['message' => 'NovotonBooking: ' . $message],
                $context
            ));
        }
    }
}
