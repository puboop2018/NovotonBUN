<a href="{$fgo_url}">{l s='Pay by fgo' mod='fgo'}</a>
