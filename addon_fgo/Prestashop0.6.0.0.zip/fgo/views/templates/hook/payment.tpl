<p class="payment_module">
  <a
    href="{$link->getModuleLink('fgo', 'validation')|escape:'html'}"
    title="{l s='Pay by fgo' mod='fgo'}"
  >
    <img
      src="{$logo_url}"
      alt="{l s='Pay by fgo' mod='fgo'}"
      width="86"
      height="49"
    />
    {l s='Pay by fgo' mod='fgo'}
  </a>
</p>
