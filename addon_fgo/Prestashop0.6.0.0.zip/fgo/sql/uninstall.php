<?php
/**
 * FGO Module uninstall script.
 */

if (!Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'fgo_invoice`')) {
    return false;
}

$column = Db::getInstance()->executeS('SHOW COLUMNS FROM `' . _DB_PREFIX_ . 'cart` LIKE "fgo"');
if (!empty($column)) {
    if (!Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . 'cart` DROP COLUMN `fgo`')) {
        return false;
    }
}
