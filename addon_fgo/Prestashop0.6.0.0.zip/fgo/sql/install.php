<?php
/**
 * FGO Module install script.
 */

$sql = array();

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'fgo_invoice` (
    `id_fgo_invoice` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `id_order` INT UNSIGNED NOT NULL,
    `id_cart` INT UNSIGNED NULL,
    `payload` LONGTEXT NULL,
    `success` TINYINT(1) NULL,
    `message` VARCHAR(255) NULL,
    `invoice_number` VARCHAR(64) NULL,
    `invoice_series` VARCHAR(32) NULL,
    `awb` VARCHAR(64) NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id_fgo_invoice`),
    UNIQUE KEY `idx_fgo_invoice_order` (`id_order`),
    KEY `idx_fgo_invoice_number` (`invoice_number`),
    KEY `idx_fgo_invoice_awb` (`awb`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;';

foreach ($sql as $query) {
    if (!Db::getInstance()->execute($query)) {
        return false;
    }
}
