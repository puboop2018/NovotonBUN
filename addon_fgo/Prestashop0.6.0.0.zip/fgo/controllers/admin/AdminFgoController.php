<?php

require_once dirname(__FILE__) . '/../../classes/FgoHelper.php';

class AdminFgoController extends ModuleAdminController
{
    /**
     * @var FgoHelper
     */
    protected $helper;

    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';

        parent::__construct();

        $this->helper = new FgoHelper();
    }

    /**
     * Handle admin actions triggered from BO links.
     *
     * @return void
     */
    public function postProcess()
    {
        $orderId = (int) Tools::getValue('fgoOid');

        if ($orderId <= 0) {
            parent::postProcess();
            return;
        }

        $redirectRequired = false;

        if (Tools::getValue('generateFgoInvoice')) {
            $this->helper->generateInvoice($orderId);
            $redirectRequired = true;
        } elseif (Tools::getValue('deleteFgoInvoice')) {
            $this->helper->updateInvoice('stergere', $orderId);
            $redirectRequired = true;
        } elseif (Tools::getValue('disableFgoInvoice')) {
            $this->helper->updateInvoice('anulare', $orderId);
            $redirectRequired = true;
        } elseif (Tools::getValue('stornoFgoInvoice')) {
            $this->helper->updateInvoice('stornare', $orderId);
            $redirectRequired = true;
        } elseif (Tools::getValue('awbFgoInvoice')) {
            $awb = Tools::getValue('awb');
            if ($awb !== null && $awb !== '') {
                $this->helper->addAWB($orderId, $awb);
                $redirectRequired = true;
            } else {
                $this->errors[] = $this->l('Please provide an AWB value.');
            }
        }

        parent::postProcess();

        if (!$redirectRequired) {
            return;
        }

        $backUrl = Tools::getValue('back');
        if (!empty($backUrl) && $backUrl !== '1') {
            $backUrl = urldecode($backUrl);
        } else {
            $backUrl = '';
        }

        if (empty($backUrl) && !empty($_SERVER['HTTP_REFERER'])) {
            $backUrl = $_SERVER['HTTP_REFERER'];
        }

        if (empty($backUrl)) {
            $backUrl = $this->context->link->getAdminLink('AdminOrders', true);
        }

        Tools::redirectAdmin($backUrl);
    }
}
