<?php
require_once dirname(__FILE__) . '/../../classes/FgoHelper.php';

class FgoApiModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        // Check if it's a POST request
        if (Tools::isSubmit('update_stock')) {
            $this->processUpdateStock();
        } elseif (Tools::isSubmit('update_payment')) {
            $this->processUpdatePayment();
        } else {
            // Default behavior or error handling
            $this->setDefaultBehavior();
        }
    }

    private function processUpdateStock()
    {
        $postData = file_get_contents('php://input');
        $jsonData = json_decode($postData, true);
        if ($jsonData !== null &&
            isset($jsonData['AuthKey']) &&
            isset($jsonData['CodConta']) &&
            isset($jsonData['Nume']) &&
            isset($jsonData['Stoc'])) {

            try {
                if (!$this->checkApiAccess($jsonData['AuthKey'])) {
                    header('Content-Type: application/json');
                    http_response_code(401);
                    echo json_encode(array('status' => 'wrong auth key'));
                    exit;
                }
                $config_values = json_decode(Configuration::get(FgoHelper::CONFIG_KEY), true);
                $selectedField = isset($config_values['articleId']) ? $config_values['articleId'] : '';
                $mapareArticolFGO = $jsonData['CodConta'];
                $mapareArticolFGOByNume = $jsonData['Nume'];
                $product_id = null;

                switch ($selectedField) {
                    case 'reference':
                        $product_id = FgoHelper::getIdByReference($mapareArticolFGO);
                        break;
                    case 'ean13':
                        $product_id = FgoHelper::getIdByEan13($mapareArticolFGO);
                        break;
                    case 'upc':
                        $product_id = FgoHelper::getIdByUpc($mapareArticolFGO);
                        break;
                    case 'isbn':
                        $product_id = FgoHelper::getIdByIsbn($mapareArticolFGO);
                        break;
                    default:
                        $product_id = FgoHelper::getIdByName($mapareArticolFGOByNume);
                        break;
                }

                if ($product_id !== null) {
                    // Update stock quantity
                    $stock = StockAvailable::getQuantityAvailableByProduct($product_id, 0);
                    $newStock = (int) $jsonData['Stoc'];

                    if ($stock !== $newStock) {
                        StockAvailable::setQuantity($product_id, 0, $newStock);
                    }

                    header('Content-Type: application/json');
                    http_response_code(200);
                    echo json_encode(array('status' => 'OK'));
                    exit;
                }

                header('Content-Type: application/json');
                http_response_code(400);
                echo json_encode(array('status' => 'OK', 'message' => 'Product not found'));
                exit;
            } catch (Exception $e) {
                $message = $e->getMessage();
                header('Content-Type: application/json');
                http_response_code(400);
                echo json_encode(array('status' => 'Error', 'message' => $message));
                exit;
            }
        }

        header('Content-Type: application/json');
        http_response_code(400); // Bad Request
        echo json_encode(array('status' => 'Error', 'message' => 'Invalid JSON data'));
        exit;
    }

    private function processUpdatePayment()
    {
        $postData = file_get_contents('php://input');
        $jsonData = json_decode($postData, true);
        if ($jsonData !== null &&
            isset($jsonData['AuthKey']) &&
            isset($jsonData['OrderId']) &&
            isset($jsonData['Paid'])) {
            if (!$this->checkApiAccess($jsonData['AuthKey'])) {
                header('Content-Type: application/json');
                http_response_code(401);
                echo json_encode(array('status' => 'wrong auth key'));
                exit;
            }
            try {
                $fgoNewOrderStatus = Configuration::get('FGO_NEW_ORDER_STATUS_ID');
                $fgoPaidOrderStatus = Configuration::get('FGO_PAID_ORDER_STATUS_ID');
                $orderId = $jsonData['OrderId'];
                $order = new Order($orderId);
                $current_status_id = $order->getCurrentOrderState()->id;

                //keep this check?
                if ($current_status_id != $fgoNewOrderStatus) {
                    header('Content-Type: application/json');
                    http_response_code(400);
                    echo json_encode(array('status' => 'Error', 'message' => 'Order Status Invalid'));
                    exit;
                } else {
                    $order->setCurrentState($fgoPaidOrderStatus);
                }
                header('Content-Type: application/json');
                http_response_code(200);
                echo json_encode(array('status' => 'OK'));
                exit;
            } catch (Exception $e) {
                $message = $e->getMessage();
                header('Content-Type: application/json');
                http_response_code(400);
                echo json_encode(array('status' => 'Error', 'message' => $message));
                exit;
            }
        }

        header('Content-Type: application/json');
        http_response_code(400); // Bad Request
        echo json_encode(array('status' => 'Error', 'message' => 'Invalid JSON data'));
        exit;
    }

    //Health Check
    private function setDefaultBehavior()
    {
        header('Content-Type: application/json');
        http_response_code(200);
        echo json_encode(array('status' => 'OK'));
        exit;
    }

    private function checkApiAccess($apiKey)
    {
        $db = Db::getInstance();
        $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'webservice_account` WHERE `key` = \'' . pSQL($apiKey) . '\'';
        $result = $db->executeS($sql);
        if ($result && count($result) > 0) {
            return true;
        }
        return false;
    }
}
