<?php
/**
 * FGO Module
 *
 * Prestashop-compatible integration without legacy overrides.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/classes/FgoHelper.php';

use PrestaShop\Module\fgo\Core\Grid\Column\Type\HtmlColumn;
use PrestaShop\PrestaShop\Core\Grid\Data\GridData;
use PrestaShop\PrestaShop\Core\Grid\Record\RecordCollection;
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class Fgo extends PaymentModule
{
    /**
     * @var array
     */
    public $config_values = array();

    /**
     * @var string[]
     */
    protected static $config_post_submit_values = array('saveConfig', 'actualizareStoc');

    /**
     * @var FgoHelper
     */
    protected $helper;

    public function __construct()
    {
        $this->name = 'fgo';
        $this->tab = 'billing_invoicing';
        $this->version = '0.6.0.0';
        $this->author = 'Fgo';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = 'FGO Premium – Billing';
        $this->description = 'FGO.ro is an online billing solution tailored for Prestashop.';
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
        $this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => '9.99.99.99');

        $this->helper = new FgoHelper();
        $this->ensureInvoiceTable();
        $this->ensureAdminTabHidden();
        $this->maybeMigrateLegacyCartData();
    }

    /**
     * Lazy helper accessor.
     *
     * @return FgoHelper
     */
    protected function getHelper()
    {
        if (!$this->helper instanceof FgoHelper) {
            $this->helper = new FgoHelper();
        }

        return $this->helper;
    }

    /**
     * Install module.
     *
     * @return bool
     */
    public function install()
    {
        include __DIR__ . '/sql/install.php';

        $installed = parent::install()
            && $this->addTab()
            && $this->createNewOrderStatus()
            && $this->createPaidOrderStatus()
            && $this->initConfig()
            && $this->registerHook('actionValidateOrder')
            && $this->registerHook('actionPaymentConfirmation')
            && $this->registerHook('displayAdminOrder')
            && $this->registerHook('actionPDFInvoiceRender')
            && $this->registerHook('actionOrderGridDefinitionModifier')
            && $this->registerHook('actionOrderGridDataModifier')
            && $this->registerHook('paymentOptions')
            && $this->registerHook('paymentReturn');

        if ($installed) {
            $this->maybeMigrateLegacyCartData();
        }

        return $installed;
    }

    /**
     * Create order status representing a pending FGO payment.
     *
     * @return bool
     */
    protected function createNewOrderStatus()
    {
        $orderState = new OrderState();
        $orderState->name = array();
        foreach (Language::getLanguages() as $language) {
            $orderState->name[$language['id_lang']] = 'Awaiting FGO Payment';
        }
        $orderState->send_email = false;
        $orderState->invoice = false;
        $orderState->color = '#4169E1';
        $orderState->unremovable = true;
        $orderState->hidden = false;
        $orderState->logable = true;
        $orderState->delivery = false;
        $orderState->shipped = false;
        $orderState->paid = false;
        $orderState->deleted = false;

        if ($orderState->add()) {
            Configuration::updateValue('FGO_NEW_ORDER_STATUS_ID', (int) $orderState->id);
            return true;
        }

        return false;
    }

    /**
     * Create order status representing payment success through FGO.
     *
     * @return bool
     */
    protected function createPaidOrderStatus()
    {
        $orderState = new OrderState();
        $orderState->name = array();
        foreach (Language::getLanguages() as $language) {
            $orderState->name[$language['id_lang']] = 'FGO Payment Successful';
        }
        $orderState->send_email = false;
        $orderState->invoice = false;
        $orderState->color = '#2e7d32';
        $orderState->unremovable = true;
        $orderState->hidden = false;
        $orderState->logable = true;
        $orderState->delivery = false;
        $orderState->shipped = false;
        $orderState->paid = false;
        $orderState->deleted = false;

        if ($orderState->add()) {
            Configuration::updateValue('FGO_PAID_ORDER_STATUS_ID', (int) $orderState->id);
            return true;
        }

        return false;
    }

    /**
     * Drop pending status by marking it deleted.
     *
     * @return bool
     */
    protected function deleteNewOrderStatus()
    {
        $id_order_state = Configuration::get('FGO_NEW_ORDER_STATUS_ID');
        if ($id_order_state && Validate::isLoadedObject(new OrderState($id_order_state))) {
            $orderState = new OrderState($id_order_state);
            $orderState->deleted = true;
            return (bool) $orderState->update();
        }

        return true;
    }

    /**
     * Drop paid status by marking it deleted.
     *
     * @return bool
     */
    protected function deletePaidOrderStatus()
    {
        $id_order_state = Configuration::get('FGO_PAID_ORDER_STATUS_ID');
        if ($id_order_state && Validate::isLoadedObject(new OrderState($id_order_state))) {
            $orderState = new OrderState($id_order_state);
            $orderState->deleted = true;
            return (bool) $orderState->update();
        }

        return true;
    }

    /**
     * Register Back Office tab for manual actions.
     *
     * @return bool
     */
    protected function addTab()
    {
        $tabId = (int) Tab::getIdFromClassName('AdminFgo');
        $tab = $tabId ? new Tab($tabId) : new Tab();
        $tab->name = array();
        foreach (Language::getLanguages() as $language) {
            $tab->name[$language['id_lang']] = 'AdminFgo';
        }

        $tab->class_name = 'AdminFgo';
        $tab->id_parent = -1;
        $tab->active = 0;
        $tab->module = $this->name;

        return $tabId ? (bool) $tab->update() : (bool) $tab->add();
    }

    /**
     * Ensure the admin tab stays hidden from the menu.
     *
     * @return void
     */
    protected function ensureAdminTabHidden()
    {
        $tabId = (int) Tab::getIdFromClassName('AdminFgo');
        if (!$tabId) {
            return;
        }

        $tab = new Tab($tabId);
        $needsUpdate = false;

        if ((int) $tab->id_parent !== -1) {
            $tab->id_parent = -1;
            $needsUpdate = true;
        }

        if ((int) $tab->active !== 0) {
            $tab->active = 0;
            $needsUpdate = true;
        }

        if ($tab->module !== $this->name) {
            $tab->module = $this->name;
            $needsUpdate = true;
        }

        if ($needsUpdate) {
            $tab->update();
        }
    }

    /**
     * Guarantee that the storage table exists (handles upgrades from legacy versions).
     *
     * @return void
     */
    protected function ensureInvoiceTable()
    {
        $db = Db::getInstance();
        $tableName = _DB_PREFIX_ . 'fgo_invoice';

        $tableExists = $db->executeS('SHOW TABLES LIKE "' . pSQL($tableName) . '"');
        if (!empty($tableExists)) {
            return;
        }

        $query = 'CREATE TABLE IF NOT EXISTS `' . $tableName . '` (
            `id_fgo_invoice` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_order` INT UNSIGNED NOT NULL,
            `id_cart` INT UNSIGNED NULL,
            `payload` LONGTEXT NULL,
            `success` TINYINT(1) NULL,
            `message` VARCHAR(255) NULL,
            `invoice_number` VARCHAR(64) NULL,
            `invoice_series` VARCHAR(32) NULL,
            `awb` VARCHAR(64) NULL,
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id_fgo_invoice`),
            UNIQUE KEY `idx_fgo_invoice_order` (`id_order`),
            KEY `idx_fgo_invoice_number` (`invoice_number`),
            KEY `idx_fgo_invoice_awb` (`awb`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;';

        $db->execute($query);
    }

    /**
     * Trigger legacy migration if not already executed.
     *
     * @return void
     */
    protected function maybeMigrateLegacyCartData()
    {
        if (Configuration::get('FGO_MIGRATED_CART_DATA')) {
            return;
        }

        $db = Db::getInstance();
        $tableName = _DB_PREFIX_ . 'fgo_invoice';
        $tableExists = $db->executeS('SHOW TABLES LIKE "' . pSQL($tableName) . '"');
        if (empty($tableExists)) {
            return;
        }

        if ($this->migrateLegacyCartData()) {
            Configuration::updateValue('FGO_MIGRATED_CART_DATA', 1);
        }
    }

    /**
     * Copy legacy payloads stored on carts to the dedicated invoice table.
     *
     * @return bool
     */
    protected function migrateLegacyCartData()
    {
        $db = Db::getInstance();
        $legacyColumn = $db->executeS(
            'SHOW COLUMNS FROM `' . _DB_PREFIX_ . 'cart` LIKE "fgo"'
        );

        if (empty($legacyColumn)) {
            return true;
        }

        $rows = $db->executeS(
            'SELECT id_cart, fgo FROM `' . _DB_PREFIX_ . 'cart` WHERE fgo IS NOT NULL AND fgo != \'\''
        );

        if (empty($rows)) {
            return true;
        }

        $allGood = true;
        foreach ($rows as $row) {
            $rawPayload = $row['fgo'];
            if (empty($rawPayload)) {
                continue;
            }

            $decoded = json_decode($rawPayload, true);
            if (!is_array($decoded)) {
                continue;
            }

            $orderId = (int) $db->getValue(
                'SELECT id_order FROM `' . _DB_PREFIX_ . 'orders` WHERE id_cart = ' . (int) $row['id_cart'] . ' ORDER BY id_order DESC'
            );

            if (!$orderId) {
                continue;
            }

            $payloadJson = json_encode($decoded);
            $success = array_key_exists('Success', $decoded) ? (int) ((bool) $decoded['Success']) : null;
            $message = isset($decoded['Message']) ? pSQL($decoded['Message']) : null;
            $invoiceNumber = isset($decoded['Factura']['Numar']) ? pSQL($decoded['Factura']['Numar']) : null;
            $invoiceSeries = isset($decoded['Factura']['Serie']) ? pSQL($decoded['Factura']['Serie']) : null;
            $awb = isset($decoded['awb']) ? pSQL($decoded['awb']) : null;
            $now = date('Y-m-d H:i:s');

            $existingId = (int) $db->getValue(
                'SELECT id_fgo_invoice FROM `' . _DB_PREFIX_ . 'fgo_invoice` WHERE id_order = ' . (int) $orderId
            );

            $data = array(
                'id_order' => (int) $orderId,
                'id_cart' => (int) $row['id_cart'],
                'payload' => pSQL($payloadJson, true),
                'success' => $success,
                'message' => $message,
                'invoice_number' => $invoiceNumber,
                'invoice_series' => $invoiceSeries,
                'awb' => $awb,
                'updated_at' => $now,
            );

            if ($existingId) {
                $allGood = $db->update('fgo_invoice', $data, 'id_fgo_invoice = ' . $existingId, 0, true) && $allGood;
            } else {
                $data['created_at'] = $now;
                $allGood = $db->insert('fgo_invoice', $data, true) && $allGood;
            }
        }

        return $allGood;
    }

    /**
     * Remove the module admin tab.
     *
     * @return bool
     */
    protected function deleteTab()
    {
        $tabId = (int) Tab::getIdFromClassName('AdminFgo');
        if ($tabId) {
            $tab = new Tab($tabId);
            return (bool) $tab->delete();
        }

        return true;
    }

    /**
     * Uninstall module.
     *
     * @return bool
     */
    public function uninstall()
    {
        include __DIR__ . '/sql/uninstall.php';

        return Configuration::deleteByName($this->name)
            && $this->deleteNewOrderStatus()
            && $this->deletePaidOrderStatus()
            && Configuration::deleteByName('FGO_MIGRATED_CART_DATA')
            && $this->deleteTab()
            && parent::uninstall();
    }

    /**
     * Set the default configuration.
     *
     * @return array|false
     */
    protected function initConfig()
    {
        $this->config_values = array(
            'platforma_url' => Tools::getHttpHost(true) . __PS_BASE_URI__,
            'platforma_api_url' => $this->context->link->getModuleLink('fgo', 'api'),
            'private_key' => '',
            'client_code' => '',
            'apiCall' => 'onOrder',
            'fgo_payment' => false,
            'sandbox' => true,
            'sanitize_vat' => false,
            'shipping_tax_vat' => 'vat_not_included',
            'articleId' => '',
            'stockManagement' => false,
            'productDesc' => false,
            'additionalInfo' => false,
            'invoice_series' => '',
            'check_duplicate' => false,
            'administration_code' => '',
            'discount_code' => '',
            'shipping_code' => '',
        );

        return $this->setConfigValues($this->config_values);
    }

    /**
     * Module configuration entry point.
     *
     * @return string
     */
    public function getContent()
    {
        $this->config_values = $this->getConfigValues();

        $this->context->smarty->assign(array(
            'module' => array(
                'class' => get_class($this),
                'name' => $this->name,
                'displayName' => $this->displayName,
                'dir' => $this->_path,
            ),
        ));

        return $this->postProcess();
    }

    /**
     * Build the configuration form definition.
     *
     * @return array
     */
    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->displayName,
                    'icon'  => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'label' => $this->l('Platforma URL'),
                        'name' => 'platforma_url',
                        'type' => 'text',
                        'required' => true,
                        'disabled' => true,
                    ),
                    /* @todo expune când endpoint-urile API publice devin stabile
                    array(
                        'label' => $this->l('Platforma API URL'),
                        'name' => 'platforma_api_url',
                        'type' => 'text',
                        'required' => true,
                        'disabled' => true,
                    ),
                    */
                    array(
                        'label' => $this->l('Parola user API'),
                        'name' => 'private_key',
                        'type' => 'text',
                        'required' => true,
                    ),
                    array(
                        'label' => $this->l('CUI (cod unic)'),
                        'name' => 'client_code',
                        'type' => 'text',
                        'required' => true,
                    ),
                    array(
                        'label' => $this->l('Alege când vrei să se emită factura FGO:'),
                        'name' => 'apiCall',
                        'type' => 'radio',
                        'values' => array(
                            array('id' => 'active_on', 'value' => 'onOrder', 'label' => $this->l('La plasarea comenzii')),
                            array('id' => 'active_off', 'value' => 'onPayment', 'label' => $this->l('La confirmarea plății')),
                            array('id' => 'active_manual', 'value' => 'manual', 'label' => $this->l('Manual')),
                        ),
                        'required' => true,
                    ),
                    array(
                        'label' => $this->l('Mod de test:'),
                        'name' => 'sandbox',
                        'type' => 'radio',
                        'values' => array(
                            array('id' => 'sandbox_active_on', 'value' => true, 'label' => $this->l('Da')),
                            array('id' => 'sandbox_active_off', 'value' => false, 'label' => $this->l('Nu')),
                        ),
                        'required' => true,
                    ),
                    /* @todo re-expune când plata cu FGO devine publică
                    array(
                        'label' => $this->l('Activează plata cu cardul by FGO:'),
                        'name' => 'fgo_payment',
                        'type' => 'radio',
                        'disabled' => true,
                        'values' => array(
                            array('id' => 'fgo_payment_on', 'value' => true, 'label' => $this->l('Da')),
                            array('id' => 'fgo_payment_off', 'value' => false, 'label' => $this->l('Nu')),
                        ),
                        'required' => true,
                    ),
                    */
                    array(
                        'label' => $this->l('Validare cod TVA pentru clienții din România:'),
                        'name' => 'sanitize_vat',
                        'type' => 'radio',
                        'values' => array(
                            array('id' => 'sanitize_vat_on', 'value' => true, 'label' => $this->l('Da')),
                            array('id' => 'sanitize_vat_off', 'value' => false, 'label' => $this->l('Nu')),
                        ),
                        'required' => true,
                    ),
                    array(
                        'label' => $this->l('TVA pe costul de livrare:'),
                        'name' => 'shipping_tax_vat',
                        'type' => 'radio',
                        'values' => array(
                            array('id' => 'vat_excluded', 'value' => 'vat_not_included', 'label' => $this->l('TVA-ul nu este inclus')),
                            array('id' => 'vat_included', 'value' => 'vat_included', 'label' => $this->l('TVA-ul este inclus')),
                            array('id' => 'vat_none', 'value' => 'without_vat', 'label' => $this->l('Fără TVA')),
                        ),
                        'required' => true,
                    ),
                    array(
                        'label' => $this->l('Verifică duplicat factură:'),
                        'name' => 'check_duplicate',
                        'type' => 'radio',
                        'values' => array(
                            array('id' => 'dup_on', 'value' => true, 'label' => $this->l('Da')),
                            array('id' => 'dup_off', 'value' => false, 'label' => $this->l('Nu')),
                        ),
                        'required' => true,
                    ),
                    array(
                        'label' => $this->l('Corespondența pentru codul de articol din FGO:'),
                        'name' => 'articleId',
                        'type' => 'radio',
                        'values' => array(
                            array('id' => 'article_none', 'value' => '', 'label' => $this->l('Niciunul')),
                            array('id' => 'article_reference', 'value' => 'reference', 'label' => $this->l('Referință')),
                            array('id' => 'article_ean13', 'value' => 'ean13', 'label' => $this->l('EAN13')),
                            array('id' => 'article_isbn', 'value' => 'isbn', 'label' => $this->l('ISBN')),
                            array('id' => 'article_upc', 'value' => 'upc', 'label' => $this->l('UPC')),
                        ),
                        'required' => true,
                    ),
                    array(
                        'label' => $this->l('Actualizează stocul produselor pe baza stocurilor FGO:'),
                        'name' => 'stockManagement',
                        'desc' => $this->l('Funcționalitate disponibilă pentru abonamentul Enterprise. Este necesară corespondență între codurile din magazin și cele din FGO.'),
                        'type' => 'radio',
                        'values' => array(
                            array('id' => 'stockManagement_yes', 'value' => true, 'label' => $this->l('Da')),
                            array('id' => 'stockManagement_no', 'value' => false, 'label' => $this->l('Nu')),
                        ),
                        'required' => true,
                    ),
                    array(
                        'label' => $this->l('Afișează codul SKU în descrierea produsului de pe factură:'),
                        'name' => 'productDesc',
                        'desc' => $this->l('Este necesară corespondență între codurile din magazin și codurile de articol din FGO.'),
                        'type' => 'radio',
                        'values' => array(
                            array('id' => 'productDesc_yes', 'value' => true, 'label' => $this->l('Da, folosește codul SKU ca descriere')),
                            array('id' => 'productDesc_no', 'value' => false, 'label' => $this->l('Nu, păstrează descrierea din FGO')),
                        ),
                        'required' => true,
                    ),
                    array(
                        'label' => $this->l('Adaugă numărul comenzii ca informație suplimentară pe factură?'),
                        'name' => 'additionalInfo',
                        'desc' => $this->l('Selectează „Da” dacă dorești ca numărul comenzii să apară în câmpul de informații suplimentare.'),
                        'type' => 'radio',
                        'values' => array(
                            array('id' => 'additionalInfo_yes', 'value' => true, 'label' => $this->l('Da')),
                            array('id' => 'additionalInfo_no', 'value' => false, 'label' => $this->l('Nu')),
                        ),
                        'required' => true,
                    ),
                    array(
                        'label' => $this->l('Gestiune'),
                        'name' => 'administration_code',
                        'type' => 'text',
                    ),
                    array(
                        'label' => $this->l('Cod articol reducere'),
                        'name' => 'discount_code',
                        'type' => 'text',
                    ),
                    array(
                        'label' => $this->l('Cod articol transport'),
                        'name' => 'shipping_code',
                        'type' => 'text',
                    ),
                    array(
                        'label' => $this->l('Alege seria de factură care se va genera'),
                        'name' => 'invoice_series',
                        'type' => 'text',
                        'required' => true,
                    ),
                ),
                'buttons' => array(
                    array(
                        'name' => 'actualizareStoc',
                        'type' => 'submit',
                        'title' => $this->l('Actualizare stoc'),
                        'class' => 'btn btn-secondary pull-right',
                        'icon' => 'process-icon-refresh',
                        'js' => "return confirm('" . addslashes($this->l('Ești sigur că vrei să actualizezi stocurile?')) . "');",
                    ),
                ),
                'submit' => array(
                    'name' => 'saveConfig',
                    'title' => $this->l('Salvează'),
                    'class' => 'btn btn-success pull-right',
                ),
            ),
        );
    }

    /**
     * Render the configuration form.
     *
     * @return string
     */
    protected function renderForm()
    {
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name . '&module_name=' . $this->name . '&tab_module=' . $this->tab;
        $this->config_values['platforma_api_url'] = $this->context->link->getModuleLink('fgo', 'api');

        $helper->tpl_vars = array(
            'fields_value' => $this->config_values,
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Retrieve configuration array from database.
     *
     * @return array
     */
    public function getConfigValues()
    {
        $value = Configuration::get($this->name);
        $decoded = $value ? json_decode($value, true) : array();

        return is_array($decoded) ? $decoded : array();
    }

    /**
     * Handle configuration form submission.
     *
     * @return string
     */
    protected function postProcess()
    {
        $output = '';

        switch ($this->getPostSubmitValue()) {
            case 'saveConfig':
                $config_keys = array_keys($this->config_values);
                foreach ($config_keys as $key) {
                    $this->config_values[$key] = Tools::getValue($key, $this->config_values[$key]);
                }

                if ($this->setConfigValues($this->config_values)) {
                    $output .= $this->displayConfirmation($this->l('Settings saved.'));
                    $check = $this->checkValidCredentials();
                    if (!$check || empty($check->Success)) {
                        $message = $check && isset($check->Message) ? $check->Message : $this->l('Credentials check failed.');
                        $output .= $this->displayError($message);
                    }
                }
                $output .= $this->renderForm();
                break;
            case 'actualizareStoc':
                $this->getHelper()->updateStockLastModified();
                $output .= $this->displayConfirmation($this->l('Stock synchronization triggered.'));
                $output .= $this->renderForm();
                break;
            default:
                $output .= $this->renderForm();
                break;
        }

        return $output;
    }

    /**
     * Validate credentials by pinging FGO.
     *
     * @return stdClass|false
     */
    protected function checkValidCredentials()
    {
        $customer_name = 'Check credentials';
        $token_key = FgoHelper::getTokenKey();
        $cui = trim($this->config_values['client_code']);

        if (empty($cui) || empty($this->config_values['private_key'])) {
            return false;
        }

        $hash = Tools::strtoupper(SHA1($cui . $this->config_values['private_key'] . $customer_name));

        $options = array();
        $options['CodUnic'] = $cui;
        $options['Hash'] = $hash;
        $options['Client']['Denumire'] = $customer_name;
        $options['Platforma'] = 'Prestashop';
        $options['Versiune'] = _PS_VERSION_;
        $options['PlatformaUrl'] = Tools::getHttpHost(true) . __PS_BASE_URI__;
        $options['VersiuneAddon'] = $this->version;
        $options['Token'] = Tools::strtoupper(SHA1('1' . '1' . $token_key));

        $url = FgoHelper::getRootApiUrl() . 'factura/check';
        $body = http_build_query($options);
        $result = false;

        if (function_exists('curl_init')) {
            $curl = curl_init($url);
            curl_setopt_array($curl, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_HTTPHEADER => array('Content-Type: application/x-www-form-urlencoded'),
                CURLOPT_TIMEOUT => 30,
            ));

            $result = curl_exec($curl);
            if ($result === false) {
                curl_close($curl);
                return false;
            }

            $statusCode = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
            curl_close($curl);

            if ($statusCode >= 400 && $statusCode < 600) {
                return false;
            }
        } else {
            $request = array(
                'http' => array(
                    'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                    'method' => 'POST',
                    'content' => $body,
                    'timeout' => 30,
                ),
            );

            $context = stream_context_create($request);
            $result = Tools::file_get_contents($url, false, $context);
        }

        return $result ? json_decode($result) : false;
    }

    /**
     * Determine which action has been submitted.
     *
     * @return string|false
     */
    protected function getPostSubmitValue()
    {
        foreach (self::$config_post_submit_values as $value) {
            if (Tools::isSubmit($value)) {
                return $value;
            }
        }

        return false;
    }

    /**
     * Set configuration array in database.
     *
     * @param array $config
     * @param bool  $merge
     *
     * @return array|false
     */
    public function setConfigValues($config, $merge = false)
    {
        if ($merge) {
            $config = array_merge($this->getConfigValues(), $config);
        }

        if (Configuration::updateValue($this->name, json_encode($config))) {
            return $config;
        }

        return false;
    }

    /**
     * Triggered when an order is validated.
     *
     * @param array $params
     */
    public function hookActionValidateOrder($params)
    {
        $orderId = isset($params['order']) ? (int) $params['order']->id : null;
        if (!$orderId) {
            return;
        }

        $helper = $this->getHelper();
        $helper->resetOrderData($orderId);

        $config_values = $this->getConfigValues();
        if (isset($config_values['apiCall']) && $config_values['apiCall'] === 'onOrder') {
            $helper->generateInvoice($orderId);
        }
    }

    /**
     * Triggered when payment confirmation is received.
     *
     * @param array $params
     */
    public function hookActionPaymentConfirmation($params)
    {
        $config_values = $this->getConfigValues();

        if (isset($config_values['apiCall']) && $config_values['apiCall'] === 'onPayment') {
            $orderId = isset($params['id_order']) ? (int) $params['id_order'] : null;
            if ($orderId) {
                $this->getHelper()->generateInvoice($orderId);
            }
        }
    }

    /**
     * Redirect to external invoice when generating PDFs.
     *
     * @param array $params
     */
    public function hookActionPDFInvoiceRender($params)
    {
        if (empty($params['order_invoice_list'])) {
            return;
        }

        foreach ($params['order_invoice_list'] as $orderInvoice) {
            if (!Validate::isLoadedObject($orderInvoice)) {
                continue;
            }

            $payload = $this->getHelper()->getInvoicePayload((int) $orderInvoice->id_order);
            if ($payload && !empty($payload['Success']) && isset($payload['Factura']['Link'])) {
                Tools::redirect($payload['Factura']['Link']);
            }
        }
    }

    /**
     * Add FGO column to order grid.
     *
     * @param array $params
     */
    public function hookActionOrderGridDefinitionModifier(array $params)
    {
        if (empty($params['definition'])) {
            return;
        }

        $definition = $params['definition'];
        $columns = $definition->getColumns();

        $htmlColumn = new HtmlColumn('fgo_col');
        $htmlColumn->setName('FGO');
        $htmlColumn->setOptions(array(
            'field' => 'id_order',
            'data' => 'fgo_data',
        ));

        $columns->addBefore('actions', $htmlColumn);
    }

    /**
     * Fill FGO column content.
     *
     * @param array $params
     */
    public function hookActionOrderGridDataModifier(array $params)
    {
        $gridData = $params['data'];
        $records = $gridData->getRecords()->all();

        $adminLink = $this->context->link->getAdminLink('AdminFgo', true);

        foreach ($records as $key => $data) {
            $id_order = (int) $data['id_order'];
            $records[$key]['fgo_data'] = $this->getOrderListerHtml($id_order, $adminLink);
        }

        $params['data'] = new GridData(
            new RecordCollection($records),
            $gridData->getRecordsTotal(),
            $gridData->getQuery()
        );
    }

    /**
     * Build BO grid action HTML.
     *
     * @param int    $id_order
     * @param string $adminLink
     *
     * @return string
     */
    public function getOrderListerHtml($id_order, $adminLink)
    {
        $helper = $this->getHelper();
        $payload = $helper->getInvoicePayload($id_order);
        $awb = $helper->getAwb($id_order);
        $baseLink = $adminLink . '&fgoOid=' . (int) $id_order;
        static $scriptInjected = false;
        $script = '';

        if (!$scriptInjected) {
            $scriptInjected = true;
            $script = '<script type="text/javascript">
                function fgoPromptAwb(orderId, baseUrl) {
                    var awb = prompt("AWB:", "");
                    if (awb === null) { return false; }
                    if (awb.trim() === "") {
                        alert("AWB nu poate fi gol.");
                        return false;
                    }
                    window.location.href = baseUrl + "&awbFgoInvoice=1&awb=" + encodeURIComponent(awb.trim());
                    return false;
                }
            </script>';
        }

        if ($payload) {
            if (empty($payload['Success'])) {
                $message = isset($payload['Message']) ? $payload['Message'] : $this->l('Invoice generation failed.');
                return $script . '<a style="color:red" title="' . htmlspecialchars($message) . '">' . $this->l('Error') . '</a> ' .
                    '<a style="color:orange" href="' . $baseLink . '&generateFgoInvoice=1">' . $this->l('Generate') . '</a>';
            }

            $link = isset($payload['Factura']['Link']) ? $payload['Factura']['Link'] : '#';
            $html = $script . '<a target="_blank" style="color:green" href="' . htmlspecialchars($link) . '">' . $this->l('View') . '</a> ';
            $html .= '<a style="color:orange" href="' . $baseLink . '&deleteFgoInvoice=1" onclick="return confirm(\'' . $this->l('Confirm delete action?') . '\');">' . $this->l('Delete') . '</a> ';
            $html .= '<a style="color:orange" href="' . $baseLink . '&disableFgoInvoice=1" onclick="return confirm(\'' . $this->l('Confirm cancel action?') . '\');">' . $this->l('Cancel') . '</a> ';
            $html .= '<a style="color:orange" href="' . $baseLink . '&stornoFgoInvoice=1" onclick="return confirm(\'' . $this->l('Confirm storno action?') . '\');">' . $this->l('Storno') . '</a>';

            if ($awb) {
                $html .= '<br /><small>AWB: ' . htmlspecialchars($awb) . '</small>';
            } else {
                $html .= '<br /><a href="#" onclick="return fgoPromptAwb(' . (int) $id_order . ', \'' . $baseLink . '\');">' . $this->l('Add AWB') . '</a>';
            }

            return $html;
        }

        return $script . '<a style="color:orange" href="' . $baseLink . '&generateFgoInvoice=1">' . $this->l('Generate') . '</a>';
    }

    /**
     * Display block inside order view page.
     *
     * @param array $params
     *
     * @return string
     */
    public function hookDisplayAdminOrder($params)
    {
        $helper = $this->getHelper();
        $orderId = (int) $params['id_order'];
        $payload = $helper->getInvoicePayload($orderId);
        $awb = $helper->getAwb($orderId);
        $adminLink = $this->context->link->getAdminLink('AdminFgo', true) . '&fgoOid=' . $orderId;
        static $scriptInjected = false;
        $script = '';

        if (!$scriptInjected) {
            $scriptInjected = true;
            $script = '<script type="text/javascript">
                function fgoPromptAwb(orderId, baseUrl) {
                    var awb = prompt("AWB:", "");
                    if (awb === null) { return false; }
                    if (awb.trim() === "") {
                        alert("AWB nu poate fi gol.");
                        return false;
                    }
                    window.location.href = baseUrl + "&awbFgoInvoice=1&awb=" + encodeURIComponent(awb.trim());
                    return false;
                }
            </script>';
        }

        $html = $script . '<div class="card panel card-panel-fgo"><div class="card-header panel-heading"><i class="material-icons icon-money">money</i> FGO</div><div class="card-body">';

        if ($payload) {
            if (empty($payload['Success'])) {
                $message = isset($payload['Message']) ? $payload['Message'] : $this->l('Invoice generation failed.');
                $html .= '<span class="badge badge-danger">' . htmlspecialchars($message) . '</span> ';
                $html .= '<a class="btn btn-default" style="color:orange" href="' . $adminLink . '&generateFgoInvoice=1">' . $this->l('Generate') . '</a>';
            } else {
                $link = isset($payload['Factura']['Link']) ? $payload['Factura']['Link'] : '#';
                $html .= '<a target="_blank" class="btn btn-default" href="' . htmlspecialchars($link) . '">' . $this->l('View invoice') . '</a> ';
                $html .= '<a class="btn btn-default" style="color:orange" href="' . $adminLink . '&deleteFgoInvoice=1" onclick="return confirm(\'' . $this->l('Delete invoice?') . '\');">' . $this->l('Delete') . '</a> ';
                $html .= '<a class="btn btn-default" style="color:orange" href="' . $adminLink . '&disableFgoInvoice=1" onclick="return confirm(\'' . $this->l('Cancel invoice?') . '\');">' . $this->l('Cancel') . '</a> ';
                $html .= '<a class="btn btn-default" style="color:orange" href="' . $adminLink . '&stornoFgoInvoice=1" onclick="return confirm(\'' . $this->l('Storno invoice?') . '\');">' . $this->l('Storno') . '</a>';

                if (!empty($payload['Factura']['LinkPlata'])) {
                    $html .= '<p class="mt-2">' . $this->l('Payment link:') . ' <input type="text" class="form-control" readonly value="' . htmlspecialchars($payload['Factura']['LinkPlata']) . '"></p>';
                }

                $html .= '<p>' . $this->l('AWB:') . ' ' . ($awb ? '<strong>' . htmlspecialchars($awb) . '</strong>' : $this->l('Not set')) .
                    ' <a href="#" onclick="return fgoPromptAwb(' . $orderId . ', \'' . $adminLink . '\');">' . ($awb ? $this->l('Update AWB') : $this->l('Add AWB')) . '</a></p>';
            }
        } else {
            $html .= '<a class="btn btn-default" style="color:orange" href="' . $adminLink . '&generateFgoInvoice=1">' . $this->l('Generate invoice') . '</a>';
        }

        $html .= '</div></div>';

        return $html;
    }

    /**
     * Provide payment option for the checkout.
     *
     * @return array
     */
    public function hookPaymentOptions()
    {
        $config_values = $this->getConfigValues();
        if (empty($config_values['fgo_payment'])) {
            return array();
        }

        $option = new PaymentOption();
        $option->setCallToActionText('Pay by FGO')
            ->setLogo(_MODULE_DIR_ . 'fgo/logo.png')
            ->setAdditionalInformation($this->l('Complete the payment via FGO secure service.'))
            ->setAction($this->context->link->getModuleLink($this->name, 'validation'));

        return array($option);
    }

    /**
     * Payment return hook.
     *
     * @param array $params
     *
     * @return string
     */
    public function hookPaymentReturn($params)
    {
        $this->smarty->assign(array(
            'fgo_url' => 'https://app.fgo.ro/',
            'id_order' => isset($params['order']) ? $params['order']->id : (isset($params['objOrder']) ? $params['objOrder']->id : null),
        ));

        return $this->display(__FILE__, 'views/templates/hook/payment_return.tpl');
    }
}
