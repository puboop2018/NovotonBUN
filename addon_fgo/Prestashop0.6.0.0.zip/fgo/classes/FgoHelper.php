<?php

require_once __DIR__ . '/Repository/FgoInvoiceRepository.php';

/**
 * Shared helper used by the FGO module.
 * Provides orchestration for API calls and persistence without relying on overrides.
 */
class FgoHelper
{
    const CONFIG_KEY = 'fgo';

    /**
     * @var FgoInvoiceRepository
     */
    private $repository;

    public function __construct(?FgoInvoiceRepository $repository = null)
    {
        $this->repository = $repository ?: new FgoInvoiceRepository();
    }

    /**
     * Retrieve module configuration from the database.
     *
     * @return array
     */
    public function getConfigValues()
    {
        $raw = Configuration::get(self::CONFIG_KEY);

        if (!$raw) {
            $legacy = Configuration::get('fgo9');
            if ($legacy) {
                $decodedLegacy = json_decode($legacy, true);
                if (is_array($decodedLegacy)) {
                    Configuration::updateValue(self::CONFIG_KEY, json_encode($decodedLegacy));
                    return $decodedLegacy;
                }
            }
        }

        $decoded = $raw ? json_decode($raw, true) : array();

        return is_array($decoded) ? $decoded : array();
    }

    /**
     * Fetch stored payload for an order.
     *
     * @param int $orderId
     * @return array|null
     */
    public function getInvoicePayload($orderId)
    {
        $record = $this->repository->findByOrderId((int) $orderId);
        if (!$record || empty($record['payload'])) {
            return null;
        }

        $payload = json_decode($record['payload'], true);

        return is_array($payload) ? $payload : null;
    }

    /**
     * Retrieve stored AWB for an order if available.
     *
     * @param int $orderId
     * @return string|null
     */
    public function getAwb($orderId)
    {
        $record = $this->repository->findByOrderId((int) $orderId);

        return $record && !empty($record['awb']) ? $record['awb'] : null;
    }

    /**
     * Remove any stored payload/AWB information for an order.
     *
     * @param int $orderId
     * @return void
     */
    public function resetOrderData($orderId)
    {
        $this->repository->deleteByOrderId((int) $orderId);
    }

    /**
     * Handle delete/anulare/stornare operations for an invoice.
     *
     * @param string $action
     * @param int    $orderId
     *
     * @return bool
     */
    public function updateInvoice($action, $orderId)
    {
        $config = $this->getConfigValues();
        $context = Context::getContext();
        $payload = $this->getInvoicePayload($orderId);

        if (!$payload || empty($payload['Factura']['Numar'])) {
            $context->controller->errors[] = Tools::displayError('Nu există o factură FGO asociată comenzii.');
            return false;
        }

        $fgoInvoiceId = $payload['Factura']['Numar'];
        $invoiceSeries = isset($payload['Factura']['Serie']) ? $payload['Factura']['Serie'] : '';

        $hash = Tools::strtoupper(sha1($config['client_code'] . $config['private_key'] . $fgoInvoiceId));
        $tokenKey = self::getTokenKey();
        $token = Tools::strtoupper(sha1((string) $invoiceSeries . $fgoInvoiceId . $tokenKey));

        $payload = array(
            'CodUnic' => $config['client_code'],
            'Hash' => $hash,
            'Numar' => $fgoInvoiceId,
            'Serie' => $invoiceSeries,
            'Token' => $token,
            'Platforma' => 'Prestashop',
            'PlatformaUrl' => Tools::getHttpHost(true) . __PS_BASE_URI__,
            'Versiune' => _PS_VERSION_,
            'VersiuneAddon' => self::getModuleVersion(),
        );

        $url = self::getRootApiUrl() . 'factura/' . $action;

        try {
            $result = $this->executeHttpPost($url, $payload);
            $decoded = $result ? json_decode($result, true) : null;

            if (!$decoded || empty($decoded['Success'])) {
                $message = $decoded && isset($decoded['Message']) ? $decoded['Message'] : 'A apărut o eroare la apelul FGO.';
                $context->controller->errors[] = $message;
                return false;
            }

            $this->repository->clearPayload($orderId);
            $this->repository->updateAwb($orderId, null);
            $context->controller->confirmations[] = 'Success: ' . $decoded['Message'];

            $this->handleBackRedirect($orderId);

            return true;
        } catch (Exception $e) {
            $context->controller->errors[] = Tools::displayError('Eroare internă. Vă rugăm contactați administratorul.');
        }

        return false;
    }

    /**
     * Attach an AWB to an existing invoice.
     *
     * @param int    $orderId
     * @param string $awb
     *
     * @return array|false
     */
    public function addAWB($orderId, $awb)
    {
        $config = $this->getConfigValues();
        $context = Context::getContext();
        $payload = $this->getInvoicePayload($orderId);

        if (!$payload || empty($payload['Factura']['Numar'])) {
            $context->controller->errors[] = Tools::displayError('Nu există o factură FGO activă pentru această comandă.');
            return false;
        }

        $invoiceNumber = $payload['Factura']['Numar'];
        $invoiceSeries = isset($payload['Factura']['Serie']) ? $payload['Factura']['Serie'] : '';

        $data = array(
            'CodUnic' => $config['client_code'],
            'Hash' => Tools::strtoupper(sha1($config['client_code'] . $config['private_key'] . $invoiceNumber)),
            'Serie' => $invoiceSeries,
            'Numar' => $invoiceNumber,
            'Platforma' => 'Prestashop',
            'PlatformaUrl' => Tools::getHttpHost(true) . __PS_BASE_URI__,
            'Versiune' => _PS_VERSION_,
            'VersiuneAddon' => self::getModuleVersion(),
            'AWB' => $awb,
        );

        $tokenKey = self::getTokenKey();
        $data['Token'] = Tools::strtoupper(sha1($invoiceSeries . $invoiceNumber . $tokenKey));

        try {
            $result = $this->executeHttpPost(self::getRootApiUrl() . 'factura/awb', $data);
            $decoded = $result ? json_decode($result, true) : null;

            if (!$decoded || empty($decoded['Success'])) {
                $message = $decoded && isset($decoded['Message']) ? $decoded['Message'] : 'A apărut o eroare la setarea AWB.';
                $context->controller->errors[] = $message;
                return false;
            }

            $this->repository->updateAwb($orderId, $awb);
            $context->controller->confirmations[] = $decoded['Message'];

            $this->handleBackRedirect($orderId);

            return $decoded;
        } catch (Exception $e) {
            $context->controller->errors[] = Tools::displayError('Eroare internă. Vă rugăm contactați administratorul.');
        }

        return false;
    }

    /**
     * Generate an invoice for a given order.
     *
     * @param int $orderId
     * @return array|false
     */
    public function generateInvoice($orderId)
    {
        $config = $this->getConfigValues();
        $cart = Cart::getCartByOrderId($orderId);
        if (!$cart) {
            return false;
        }

        $context = Context::getContext();
        $currency = new Currency($cart->id_currency);
        $tokenKey = self::getTokenKey();

        $customerAddress = new Address((int) $cart->id_address_invoice);
        $customerName = !empty($customerAddress->company) && !ctype_space($customerAddress->company)
            ? $customerAddress->company
            : $customerAddress->firstname . ' ' . $customerAddress->lastname;
        $order = new Order($orderId);
        $products = $order->getProducts();

        $options = array('Continut' => array());

        $tva = 0;
        foreach ($products as $product) {
            $newProduct = array(
                'Denumire' => $product['product_name'],
                'NrProduse' => $product['product_quantity'],
                'PretTotal' => $product['total_price_tax_incl'],
                'UM' => 'H87',
            );

            if ($newProduct['PretTotal'] < 0) {
                $newProduct['PretTotal'] = abs($newProduct['PretTotal']);
                $newProduct['NrProduse'] = -1 * $newProduct['NrProduse'];
            }

            $tva = $product['tax_rate'];
            $newProduct['CotaTVA'] = $tva;

            if (!empty($config['administration_code'])) {
                $newProduct['CodGestiune'] = $config['administration_code'];
            }

            if (!empty($config['articleId']) && array_key_exists('product_' . $config['articleId'], $product)) {
                $newProduct['CodArticol'] = $product['product_' . $config['articleId']];
                if (!empty($config['productDesc'])) {
                    $newProduct['Descriere'] = 'SKU: ' . $newProduct['CodArticol'];
                }
            }

            $options['Continut'][] = $newProduct;
        }

        $shippingCost = $cart->getPackageShippingCost();
        if ($shippingCost > 0) {
            $codGestiune = !empty($config['administration_code']) ? $config['administration_code'] : null;
            $codArticolTransport = !empty($config['shipping_code']) ? $config['shipping_code'] : null;
            $shippingLine = array(
                'Denumire' => 'Cost transport',
                'CodArticol' => $codArticolTransport,
                'UM' => 'SX',
                'NrProduse' => 1,
                'CodGestiune' => $codGestiune,
            );

            if ($config['shipping_tax_vat'] == 'vat_not_included') {
                $shippingLine['PretUnitar'] = $shippingCost;
                $shippingLine['CotaTVA'] = 21;
            } elseif ($config['shipping_tax_vat'] == 'vat_included') {
                $shippingLine['PretTotal'] = $shippingCost;
                $shippingLine['CotaTVA'] = 21;
            } else {
                $shippingLine['PretUnitar'] = $shippingCost;
                $shippingLine['CotaTVA'] = 0;
            }

            $options['Continut'][] = $shippingLine;
        }

        $discount = $order->total_discounts_tax_incl;
        if ($discount > 0) {
            $options['Continut'][] = array(
                'Denumire' => 'Reducere',
                'CodArticol' => !empty($config['discount_code']) ? $config['discount_code'] : null,
                'PretTotal' => $discount,
                'UM' => 'H87',
                'NrProduse' => -1,
                'CotaTVA' => $tva,
                'CodGestiune' => !empty($config['administration_code']) ? $config['administration_code'] : null,
            );
        }

        $hash = Tools::strtoupper(sha1($config['client_code'] . $config['private_key'] . $customerName));
        $customer = new Customer((int) $customerAddress->id_customer);

        $options['CodUnic'] = $config['client_code'];
        $options['Hash'] = $hash;
        $options['DataEmitere'] = date('Y-m-d');
        $options['Client']['Denumire'] = $customerName;

        $codUnicClient = '';
        if (!empty($customerAddress->vat_number)) {
            $codUnicClient = trim($customerAddress->vat_number);
            $codUnicClient = strtoupper($codUnicClient);
            if (strpos($codUnicClient, 'RO') === 0) {
                $codUnicClient = trim(substr($codUnicClient, 2));
            }
            $options['Client']['PlatitorTVA'] = 'true';
        } elseif (!empty($customerAddress->dni)) {
            $codUnicClient = trim($customerAddress->dni);
        }
        $options['Client']['CodUnic'] = $codUnicClient;

        if (!empty($config['sanitize_vat'])) {
            $options['ValideazaCodUnicRo'] = 'true';
        }

        $idExtern = $customer->id_guest ? $customer->id_guest : $customer->id;
        $options['Client']['IdExtern'] = $idExtern;
        $stateName = State::getNameById($customerAddress->id_state);
        if ($stateName && $stateName !== '0') {
            if ($stateName !== 'Satu Mare') {
                $stateName = str_replace(' ', '-', $stateName);
            }
            $options['Client']['Judet'] = $stateName;
        }

        $countryIso = Country::getIsoById($customerAddress->id_country);
        $options['Client']['Tara'] = $countryIso;
        $options['Client']['Tip'] = !empty($customerAddress->vat_number) && !ctype_space($customerAddress->vat_number) ? 'PJ' : 'PF';
        $options['Client']['Adresa'] = trim($customerAddress->address1 . ' ' . $customerAddress->address2);
        $options['Client']['Localitate'] = $customerAddress->city;
        $options['Client']['Telefon'] = !empty($customerAddress->phone) ? $customerAddress->phone : $customerAddress->phone_mobile;

        if (!empty($config['additionalInfo'])) {
            $options['Explicatii'] = 'Comanda ' . (string) $orderId;
        }

        $options['Valuta'] = $currency->iso_code;
        $options['TipFactura'] = 'Factura';
        $options['VerificareDuplicat'] = !empty($config['check_duplicate']) ? 'True' : 'False';
        $options['Platforma'] = 'Prestashop';
        $options['Versiune'] = _PS_VERSION_;
        $options['VersiuneAddon'] = self::getModuleVersion();
        $options['PlatformaUrl'] = Tools::getHttpHost(true) . __PS_BASE_URI__;
        $options['IdExtern'] = $orderId;
        $options['Token'] = Tools::strtoupper(sha1($orderId . $options['Client']['IdExtern'] . $tokenKey));
        if (!empty($config['invoice_series'])) {
            $options['Serie'] = $config['invoice_series'];
        }

        try {
            $result = $this->executeHttpPost(self::getRootApiUrl() . 'factura/emitere', $options);
            if (!$result) {
                throw new Exception('A intervenit o eroare la apelarea serviciului FGO.');
            }

            $decoded = json_decode($result, true);
            if (!$decoded) {
                throw new Exception('Răspunsul FGO nu este valid.');
            }

            $infoStock = array();
            if (isset($decoded['InfoStoc'])) {
                $infoStock = $decoded['InfoStoc'];
                unset($decoded['InfoStoc']);
            }

            $this->repository->savePayload($orderId, (int) $cart->id, $decoded);

            if (!empty($config['stockManagement']) && count($infoStock) > 0) {
                $this->updateStockAfterInvoice($orderId, $infoStock);
            }

            $this->handleBackRedirect($orderId);

            return $decoded;
        } catch (Exception $e) {
            $context->controller->errors[] = Tools::displayError($e->getMessage());
        }

        return false;
    }

    /**
     * Execute an HTTP POST request using cURL when available.
     *
     * @param string $url
     * @param array  $payload
     *
     * @return string
     *
     * @throws Exception
     */
    protected function executeHttpPost($url, array $payload)
    {
        $body = http_build_query($payload);

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_HTTPHEADER => array('Content-Type: application/x-www-form-urlencoded'),
                CURLOPT_TIMEOUT => 30,
            ));

            $result = curl_exec($ch);
            if ($result === false) {
                $error = curl_error($ch);
                curl_close($ch);
                throw new Exception('cURL error: ' . $error);
            }

            $statusCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($statusCode >= 400 && $statusCode < 600) {
                throw new Exception('FGO API HTTP ' . $statusCode);
            }

            return $result;
        }

        $context = stream_context_create(array(
            'http' => array(
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => $body,
                'timeout' => 30,
            ),
        ));

        $result = Tools::file_get_contents($url, false, $context);
        if ($result === false) {
            throw new Exception('HTTP request failed.');
        }

        return $result;
    }

    /**
     * Update Prestashop stock based on the FGO API response.
     *
     * @param int   $orderId
     * @param array $infoStock
     *
     * @return void
     */
    public function updateStockAfterInvoice($orderId, $infoStock)
    {
        $order = new Order($orderId);
        $config = $this->getConfigValues();
        $orderProducts = $order->getProducts();
        $productSkuList = array();

        foreach ($orderProducts as $item) {
            if (!empty($config['articleId']) && array_key_exists('product_' . $config['articleId'], $item)) {
                $sku = $item['product_' . $config['articleId']];
                if (!empty($sku)) {
                    $productSkuList[] = $sku;
                }
            }
        }

        if (empty($productSkuList)) {
            return;
        }

        foreach ($infoStock as $element) {
            if (is_object($element)) {
                $element = (array) $element;
            }

            $code = isset($element['CodConta']) ? $element['CodConta'] : (isset($element['CodArticol']) ? $element['CodArticol'] : null);
            $stockValue = isset($element['Stoc']) ? $element['Stoc'] : null;

            if (!$code || $stockValue === null) {
                continue;
            }

            foreach ($orderProducts as $item) {
                if (!empty($config['articleId']) && array_key_exists('product_' . $config['articleId'], $item)) {
                    $sku = $item['product_' . $config['articleId']];
                    if ($sku && $sku === $code) {
                        StockAvailable::setQuantity($item['product_id'], 0, (int) $stockValue);
                    }
                }
            }
        }
    }

    /**
     * Fetch stock changes from FGO and sync locally.
     *
     * @return void
     */
    public function updateStockLastModified()
    {
        $config = $this->getConfigValues();
        $url = self::getRootApiUrl() . 'articol/articolemodificate';
        $codUnic = $config['client_code'];
        $privateKey = $config['private_key'];
        $tokenKey = self::getTokenKey();

        $data = array(
            'CodUnic' => $codUnic,
            'Serie' => '',
            'Numar' => '',
            'Hash' => Tools::strtoupper(SHA1($codUnic . $privateKey)),
            'Platforma' => 'Prestashop',
            'PlatformaUrl' => Tools::getHttpHost(true) . __PS_BASE_URI__,
            'Versiune' => _PS_VERSION_,
            'VersiuneAddon' => self::getModuleVersion(),
            'Token' => Tools::strtoupper(SHA1($tokenKey)),
            'NumarOre' => '170',
        );

        try {
            $result = $this->executeHttpPost($url, $data);
        } catch (Exception $e) {
            return;
        }

        $response = json_decode($result);

        if ($response && isset($response->Success) && $response->Success && isset($response->Result)) {
            $this->updateAllStockInvoice($response->Result);
        }
    }

    /**
     * Bulk update stock entries based on a list returned by FGO.
     *
     * @param array $productList
     *
     * @return void
     */
    public function updateAllStockInvoice($productList)
    {
        $config = $this->getConfigValues();

        foreach ($productList as $product) {
            if (is_object($product)) {
                $product = (array) $product;
            }

            if (!isset($product['CodConta']) || !isset($product['Stoc'])) {
                continue;
            }

            $productId = null;
            switch ($config['articleId']) {
                case 'reference':
                    $productId = self::getIdByReference($product['CodConta']);
                    break;
                case 'ean13':
                    $productId = self::getIdByEan13($product['CodConta']);
                    break;
                case 'upc':
                    $productId = self::getIdByUpc($product['CodConta']);
                    break;
                case 'isbn':
                    $productId = self::getIdByIsbn($product['CodConta']);
                    break;
                default:
                    $productId = self::getIdByName($product['Nume']);
                    break;
            }

            if ($productId) {
                StockAvailable::setQuantity($productId, 0, (int) $product['Stoc']);
            }
        }
    }

    public static function getIdByReference($product_reference)
    {
        $product = Product::getIdByReference(self::convertDiacritics($product_reference));
        return $product ? (int) $product : null;
    }

    public static function getIdByEan13($product_ean)
    {
        return Product::getIdByEAN13(self::convertDiacritics($product_ean));
    }

    public static function getIdByUpc($upc)
    {
        return Product::getIdByUPC(self::convertDiacritics($upc));
    }

    public static function getIdByIsbn($isbn)
    {
        return Product::getIdByISBN(self::convertDiacritics($isbn));
    }

    public static function getIdByName($name)
    {
        $result = Db::getInstance()->getRow(
            '
            SELECT id_product FROM `' . _DB_PREFIX_ . 'product_lang`
            WHERE name = \'' . pSQL(self::convertDiacritics($name)) . '\''
        );

        return $result ? (int) $result['id_product'] : null;
    }

    public static function convertDiacritics($string)
    {
        return preg_replace('/[^a-zA-Z0-9.\s]/', '', iconv('UTF-8', 'ASCII//TRANSLIT', $string));
    }

    public static function getRootApiUrl()
    {
        $raw = Configuration::get(self::CONFIG_KEY);
        $config = $raw ? json_decode($raw, true) : array();
        $sandbox = isset($config['sandbox']) ? (bool) $config['sandbox'] : true;

        return $sandbox ? 'https://api-testuat.fgo.ro/v1/' : 'https://api.fgo.ro/v1/';
    }

    public static function getModuleVersion()
    {
        $module = Module::getInstanceByName('fgo');

        return $module ? $module->version : '0.6.0.0';
    }

    public static function getTokenKey()
    {
        return '4C490B5C';
    }

    /**
     * Handle redirection after an admin action when needed.
     *
     * @param int $orderId
     * @return void
     */
    private function handleBackRedirect($orderId)
    {
        if (!Tools::getValue('back')) {
            return;
        }

        $context = Context::getContext();
        if (Tools::getValue('back') === 'lister') {
            Tools::redirectAdmin($context->link->getAdminLink('AdminOrders'));
        }

        Tools::redirectAdmin(
            $context->link->getAdminLink('AdminOrders', true, array(), array('id_order' => (int) $orderId, 'vieworder' => 1)) .
            '&id_order=' . (int) $orderId .
            '&vieworder'
        );
    }
}
