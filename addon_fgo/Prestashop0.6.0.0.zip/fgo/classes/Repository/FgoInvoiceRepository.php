<?php

/**
 * Lightweight repository responsible for persisting FGO integration data.
 * Stores FGO API payloads outside the core PrestaShop tables to avoid overrides.
 */
class FgoInvoiceRepository
{
    /**
     * @var Db
     */
    private $db;

    /**
     * @param Db|null $db
     */
    public function __construct($db = null)
    {
        $this->db = $db ?: Db::getInstance();
    }

    /**
     * Returns the fully-qualified table name.
     *
     * @return string
     */
    private function getTableName()
    {
        return _DB_PREFIX_ . 'fgo_invoice';
    }

    /**
     * Fetch an invoice record by order id.
     *
     * @param int $orderId
     * @return array|null
     */
    public function findByOrderId($orderId)
    {
        $query = new DbQuery();
        $query->select('*')
            ->from('fgo_invoice')
            ->where('id_order = ' . (int) $orderId);

        $row = $this->db->getRow($query);

        return $row ?: null;
    }

    /**
     * Create or update a payload entry.
     *
     * @param int   $orderId
     * @param int   $cartId
     * @param array $payload
     *
     * @return bool
     */
    public function savePayload($orderId, $cartId, array $payload)
    {
        $now = date('Y-m-d H:i:s');
        $existing = $this->findByOrderId($orderId);
        $data = array(
            'id_order' => (int) $orderId,
            'id_cart' => (int) $cartId,
            'payload' => json_encode($payload),
            'success' => isset($payload['Success']) ? (int) (bool) $payload['Success'] : null,
            'message' => isset($payload['Message']) ? pSQL($payload['Message']) : null,
            'invoice_number' => isset($payload['Factura']['Numar']) ? pSQL($payload['Factura']['Numar']) : null,
            'invoice_series' => isset($payload['Factura']['Serie']) ? pSQL($payload['Factura']['Serie']) : null,
            'updated_at' => $now,
        );

        if ($existing) {
            return $this->db->update(
                'fgo_invoice',
                $data,
                'id_order = ' . (int) $orderId
            );
        }

        $data['created_at'] = $now;

        return $this->db->insert('fgo_invoice', $data);
    }

    /**
     * Clear payload data for an order.
     *
     * @param int $orderId
     * @return bool
     */
    public function clearPayload($orderId)
    {
        $data = array(
            'payload' => null,
            'success' => null,
            'message' => null,
            'invoice_number' => null,
            'invoice_series' => null,
            'updated_at' => date('Y-m-d H:i:s'),
        );

        return $this->db->update('fgo_invoice', $data, 'id_order = ' . (int) $orderId);
    }

    /**
     * Persist AWB information for an order.
     *
     * @param int         $orderId
     * @param string|null $awb
     *
     * @return bool
     */
    public function updateAwb($orderId, $awb)
    {
        $existing = $this->findByOrderId($orderId);

        if (!$existing) {
            $data = array(
                'id_order' => (int) $orderId,
                'id_cart' => null,
                'payload' => null,
                'success' => null,
                'message' => null,
                'invoice_number' => null,
                'invoice_series' => null,
                'awb' => $awb !== null ? pSQL($awb) : null,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            );

            return $this->db->insert('fgo_invoice', $data);
        }

        $data = array(
            'awb' => $awb !== null ? pSQL($awb) : null,
            'updated_at' => date('Y-m-d H:i:s'),
        );

        return $this->db->update('fgo_invoice', $data, 'id_order = ' . (int) $orderId);
    }

    /**
     * Hard delete record when module uninstalls.
     *
     * @return bool
     */
    public function truncate()
    {
        return $this->db->execute('TRUNCATE TABLE `' . pSQL($this->getTableName()) . '`');
    }

    /**
     * Delete a record for a given order id.
     *
     * @param int $orderId
     * @return bool
     */
    public function deleteByOrderId($orderId)
    {
        return $this->db->delete('fgo_invoice', 'id_order = ' . (int) $orderId);
    }
}
