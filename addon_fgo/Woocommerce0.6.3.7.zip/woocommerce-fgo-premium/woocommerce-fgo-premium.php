<?php

/**
 * Plugin Name: FGO Premium
 * Plugin URI: https://www.fgo.ro
 * Description: Conecteaza magazinul tau online la plaforma de facturare FGO.
 * Version:0.6.3.7
 * Author: i-Tom Solutions
 * Author URI: https://www.fgo.ro
 * License: GPL2
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

include('includes/fgo-config.php');
include('includes/fgo-premium-settings.php');
include('includes/fgo-premium-order.php');
include('includes/fgo-order-page.php');
include('includes/fgo-billing.php');
include('includes/fgo-client-page.php');

WC_FGO_Premium_Settings::init();
WC_FGO_Premium_Order::init();
WC_FGO_Order_Page::init();
WC_FGO_Billing::init();
WC_FGO_Client_Page::init();

$FGO_SETTINGS_ARRAY = array(
    'wc_settings_tab_fgo_site_url' => 'fgo_site_url',
    'wc_settings_tab_fgo_private_key' => 'fgo_private_key',
    'wc_settings_tab_fgo_client_code' => 'fgo_client_code',
    'wc_settings_tab_fgo_sandbox'=>'fgo_sandbox',
    'wc_settings_tab_fgo_client_vat'=>'fgo_vat',
    //'wc_settings_tab_fgo_client_vat_external'=> 'fgo_vat_external',
    'wc_settings_tab_fgo_client_vat_fgo'=> 'fgo_client_vat_fgo',
    'wc_settings_tab_fgo_client_cnp_obligatoriu'=> 'fgo_client_cnp_obligatoriu',
    'wc_settings_tab_fgo_client_vat_field'=>'fgo_vat_field', 
    'wc_settings_tab_fgo_client_cnp_field'=>'fgo_cnp_field',
    'wc_settings_tab_fgo_client_firma_field'=>'fgo_firma_field',
    'wc_settings_tab_fgo_client_nrRegCom_field'=>'fgo_nrRegCom_field',
    'wc_settings_tab_fgo_client_vat_sanitize'=>'fgo_vat_sanitize',
    'wc_settings_tab_fgo_insert_cc' =>'fgo_insert_cc' ,
    'wc_settings_tab_fgo_insert_shipping'=>'fgo_insert_shipping',
    'wc_settings_tab_fgo_shipping_vat'=>'fgo_shipping_vat',
    'wc_settings_tab_fgo_shipping_vat_type'=>'fgo_shipping_vat_type',
    'wc_settings_tab_fgo_product_mapping'=>'fgo_product_mapping',
    'wc_settings_tab_fgo_stock_management'=>'fgo_stock_management',
    'wc_settings_tab_fgo_undo_stock'=>'fgo_undo_stock',
    'wc_settings_tab_fgo_product_description'=>'fgo_product_description',
    'wc_settings_tab_fgo_product_management'=> 'fgo_product_management',
    'wc_settings_tab_fgo_product_management_shipping'=>'fgo_product_management_shipping',
    'wc_settings_tab_fgo_shipping_mapping'=>'fgo_shipping_mapping',
    'wc_settings_tab_fgo_discount_mapping'=>'fgo_discount_mapping',
    'wc_settings_tab_fgo_check_duplicates'=>'wc_settings_tab_fgo_check_duplicates',
    'wc_settings_tab_fgo_invoice_type'=>'fgo_invoice_type',
    'wc_settings_tab_fgo_desc_items'=>'fgo_desc_items',
    'wc_settings_tab_fgo_api_call'=>'fgo_api_call',
    'wc_settings_tab_fgo_discount_invoice'=>'fgo_discount_invoice',
    'wc_settings_tab_fgo_check_debug'=>'fgo_check_debug',
    'wc_settings_tab_fgo_series_option'=>'fgo_series_option',
    'wc_settings_tab_fgo_invoice_series'=>'fgo_invoice_series',
    'wc_settings_tab_fgo_invoice_series_editor'=>'fgo_series_editor',
    'wc_settings_tab_fgo_invoice_series_administrator'=>'fgo_series_administrator'
);