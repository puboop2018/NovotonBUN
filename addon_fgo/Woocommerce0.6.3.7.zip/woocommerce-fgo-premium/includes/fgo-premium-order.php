<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController;

class WC_FGO_Premium_Order {


    public static function buildFactura($order_id){
        $order = new WC_Order($order_id);
        $order_data = $order->get_data();
        $key = "4C490B5C";

        $current_user = wp_get_current_user();
        $current_user_id = $current_user->ID;
        $current_user_role = $current_user->roles[0];

        $send_series = get_option('wc_settings_tab_fgo_series_option');

        if($send_series == '0'){
            $invoice_series = get_option('wc_settings_tab_fgo_invoice_series');
        }
        else if($send_series == '1'){
            $invoice_series = get_option('wc_settings_tab_fgo_invoice_series_'.$current_user_role.'');
        }

        $order_billing_first_name = $order_data['billing']['first_name'];
        $order_billing_last_name = $order_data['billing']['last_name'];
        $order_billing_company = $order_data['billing']['company'];

        $order_billing_address_1 = $order_data['billing']['address_1'];

        $codUnic = get_option('wc_settings_tab_fgo_client_code');
        $privateKey = get_option('wc_settings_tab_fgo_private_key');
        $denumire = ($order_billing_company !== '') ? $order_billing_company : get_post_meta( $order_id, 'woocommerce_fgo_billing_company', true );
        $tip_facturare_request = isset($_POST['wc_order_billing_tip_facturare_fgo_client'])
            ? sanitize_text_field(wp_unslash($_POST['wc_order_billing_tip_facturare_fgo_client']))
            : '';
        $tip_facturare_meta = $order->get_meta('_billing_tip_facturare', true);
        $tip_facturare = $tip_facturare_request !== '' ? $tip_facturare_request : $tip_facturare_meta;
        if ($tip_facturare === 'pers-fiz') {
            $tip_facturare = '2';
        } elseif ($tip_facturare === 'pers-jur') {
            $tip_facturare = '1';
        }

        if (get_option('wc_settings_tab_fgo_client_vat_fgo') == '1') {
            $requires_company = ($tip_facturare === '1' || ($tip_facturare === '' && !empty($denumire)));
            if ($requires_company && empty($denumire)) {
                $message = __('Nu puteți genera factura FGO fără denumirea companiei atunci când este selectată facturarea pentru persoană juridică.', 'woocommerce');
                return wp_json_encode(array('Success' => false, 'Message' => $message));
            }

            if ($tip_facturare === '2') {
                $denumire = $order_billing_first_name . ' ' . $order_billing_last_name;
                $data['Client[Tip]'] = 'PF';
            } elseif (!empty($denumire)) {
                $data['Client[Tip]'] = 'PJ';
            } else {
                $denumire = $order_billing_first_name . ' ' . $order_billing_last_name;
                $data['Client[Tip]'] = 'PF';
            }

        }
        else {
            if (empty($denumire) || $tip_facturare === '2') {
                $denumire = $order_billing_first_name . ' ' . $order_billing_last_name;
                $data['Client[Tip]'] = 'PF';
            }
            else{
                $data['Client[Tip]'] = 'PJ';
            }
        }

        if (!empty($invoice_series))
        {
            $data['Serie'] = $invoice_series;
        }
        $data['CodUnic'] = $codUnic;
        $data['Hash'] = strtoupper(SHA1($codUnic . $privateKey . CONFIG::convertDiacritics2($denumire)));

        if (get_option('wc_settings_tab_fgo_invoice_type') == 'notice')
            $data['TipFactura'] = CONFIG::$FGO_TIP_AVIZ;
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'order')
            $data['TipFactura'] = CONFIG::$FGO_TIP_PROFORMA;
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'comanda')
            $data['TipFactura'] = CONFIG::$FGO_TIP_COMANDA;
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_T')
            $data['TipFactura'] = 'T';
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_S')
            $data['TipFactura'] = 'S';
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_U')
            $data['TipFactura'] = 'U';
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_H')
            $data['TipFactura'] = 'H';
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_n')
            $data['TipFactura'] = 'n';
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_X')
            $data['TipFactura'] = 'X';
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_N')
            $data['TipFactura'] = 'N';
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_M')
            $data['TipFactura'] = 'M';
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_Y')
            $data['TipFactura'] = 'Y';
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_D')
            $data['TipFactura'] = 'D';
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_d')
            $data['TipFactura'] = 'd';
        else if (get_option('wc_settings_tab_fgo_invoice_type') == 'invoice_L')
            $data['TipFactura'] = 'L';
        else
            $data['TipFactura'] = CONFIG::$FGO_TIP_FACTURA;

        if(get_option('wc_settings_tab_fgo_check_duplicates') == '0')
            $data['VerificareDuplicat'] = 'false';
        else
            $data['VerificareDuplicat'] = 'true';

        $pret_include_taxa = $order_data["prices_include_tax"];
        $afisare_taxa = get_option('woocommerce_tax_total_display');

        $valuta = $order->get_currency();
        $data['Valuta'] =  $valuta; // get_option('woocommerce_currency');
        if (empty($valuta))
            $data['Valuta'] = CONFIG::$FGO_VALUTA;
        
        //$data['DataEmitere'] = $order->get_date_created()->format('Y-m-d');
        // if(strtoupper($data['Valuta']) == 'RON')
        //   $data['Valuta'] = 'LEU';
        $data['Client[Denumire]'] = CONFIG::convertDiacritics2($denumire);
        //$data['Client[CodUnic]'] = '';
        //$data['Client[Tip]'] = $order_billing_tip_client;
        $data['Client[IdExtern]'] = CONFIG::normalize_customer_id_for_api($order_data['customer_id']);

        $cnp = null;
        $vat = null;
        $nr_reg_com = '';
        if($data['Client[Tip]'] == 'PJ'){
            
            $nr_reg_com = get_post_meta( $order_id, 'woocommerce_fgo_billing_reg', true );

            if (get_option('wc_settings_tab_fgo_client_vat') == '1'){ // || get_option('wc_settings_tab_fgo_client_vat_external') == '1'
                $vat = get_post_meta( $order_id, 'woocommerce_fgo_billing_cui', true );
                $nr_reg_com = get_post_meta( $order_id, 'woocommerce_fgo_billing_reg', true );
            }
            else
            {
                $vatField = get_option('wc_settings_tab_fgo_client_vat_field');
                $nrRegComField = get_option('wc_settings_tab_fgo_client_nrRegCom_field');
                if (isset($vatField) && !empty($vatField))
                {
                    $vat = get_post_meta( $order_id, $vatField, true );
                    if (empty($vat))
                    {
                        $vat = get_post_meta( $order_id, 'woocommerce_fgo_billing_cui', true );
                    }
                }
                if (isset($nrRegComField) && !empty($nrRegComField))
                {
                    $nr_reg_com = get_post_meta( $order_id, $nrRegComField, true );
                    if (empty($nr_reg_com))
                    {
                        $nr_reg_com = get_post_meta( $order_id, 'woocommerce_fgo_billing_reg', true );
                    }
                }
            }

            if (isset($vat))
            {
                $vat_numeric = $vat;
                if(!is_int($vat)){
                    $vat_numeric = strtoupper(trim($vat));

                    // Check if first two characters are letters (A-Z)
                    if (preg_match('/^[A-Z]{2}/', $vat_numeric)) {
                        // Remove the first two letters
                        $vat_numeric = substr($vat_numeric, 2);
                        $data['Client[PlatitorTVA]'] = 'true';
                    }

                    // If it starts with 0, remove the leading zero(s)
                    if (strpos($vat_numeric, '0') === 0) {
                        $vat_numeric = ltrim($vat_numeric, '0');
                    }
                }
                // Elimină orice caracter care nu e cifră
                $vat_numeric = preg_replace('/\D/', '', $vat_numeric);
                // Dacă e prea lung pentru int32, păstrează ultimele 9 cifre
                if (strlen($vat_numeric) > 10) {
                    $vat_numeric = substr($vat_numeric, -9);
                }

                $data['Client[CodUnic]'] = $vat;
                $data['Client[NrRegCom]'] = $nr_reg_com;
                $data['Client[IdExtern]'] =  CONFIG::normalize_customer_id_for_api($vat_numeric);
            }
        }
        else 
        {   
            $cnp = get_post_meta( $order_id, 'woocommerce_fgo_billing_cui', true );
            if ($cnp != null && empty($cnp) ==false)
            {
                $data['Client[CodUnic]'] = $cnp;
            }
        }

        if (get_option('wc_settings_tab_fgo_client_vat_sanitize') == '1')
        {
            $data['ValideazaCodUnicRo'] = 'true';
        }
        else
        {
            $data['ValideazaCodUnicRo'] = 'false';
        }

        $data['Client[Email]'] = $order_data['billing']['email'];
        $data['Client[Telefon]'] = $order_data['billing']['phone'];
        $data['Client[Tara]'] = $order_data['billing']['country'];

        if($data['Client[Tara]'] != null && $data['Client[Tara]'] != 'RO')
            $data['Client[Strain]'] = "true";

        $data['Client[Judet]'] = $order->get_billing_state();
        $data['Client[Localitate]'] = $order->get_billing_city();
        $data['Client[Adresa]'] =  formatted_billing_address($order);

        $data['Platforma'] = CONFIG::$FGO_PLATFORMA;
        $site_name = CONFIG::fgo_get_site_url();
        if ($site_name == '')
            $data['PlatformaUrl'] = get_option('wc_settings_tab_fgo_site_url');
        else $data['PlatformaUrl'] = $site_name;
        $data['Versiune'] = WC()->version;
        $data['VersiuneAddon'] = CONFIG::$FGO_VERSIUNE_MODUL;
        $data['Continut'] = array();
        $data['IdExtern'] = $order_id;
        $tmpIdExtern = CONFIG::normalize_customer_id_for_api($data['Client[IdExtern]']);
        $data['Token'] = strtoupper(SHA1($order_id . $tmpIdExtern . $key));
        if (get_option('wc_settings_tab_fgo_insert_cc') == '1')
        {
            $data['Text'] = 'Note: ' . $order->customer_message;
        }

        $payment =  '';
        if(!empty($order->get_payment_method_title())){
            $payment = strip_tags($order->get_payment_method_title());
        }

        $descSettings = serialize(get_option('wc_settings_tab_fgo_desc_items'));
        $data['Explicatii'] = '';

        if(strpos($descSettings, CONFIG::$FGO_DESC_ORDERID) != false){
            $data['Explicatii'] = $data['Explicatii'] . 'Comanda nr. ' . $order_id . '|' ;
        }
        if(strpos($descSettings, CONFIG::$FGO_DESC_PAYMENT) != false){
            $data['Explicatii'] = $data['Explicatii'] . 'Modalitate plata: ' . $payment . '  |';
        }
        if(strpos($descSettings,  CONFIG::$FGO_DESC_SHIPPING ) != false){
            $data['Explicatii'] = $data['Explicatii'] . ' Modalitate livrare: ' . $order->get_shipping_method();
        }

        $tva = 0;

        foreach ($order->get_items() as $item_id => $item_obj) {
            $item_data = $item_obj->get_data();

            $item = array();
            
            $search_symbols = ['"', '™️', '™'];
            $replace_symbols = ['', '', '']; 

            $item['Denumire'] = strip_tags($item_data['name']);
            $item['Denumire'] = preg_replace('/[™™️"]/', '', $item['Denumire']);         

            $item['NrProduse'] = $item_data['quantity'];

            $product = $item_obj->get_product();

            if (get_option('wc_settings_tab_fgo_product_mapping') == '1')
            {
                $item['CodArticol'] = $product->get_sku();

                if(get_option('wc_settings_tab_fgo_product_description') == 1){
                    $item['Descriere'] = "Cod SKU: " .  $item['CodArticol'];
                }
            }        

            // Only for product variation
            if ($product->is_type('variation')) {
                // Initialize the description if it hasn't been set already
                if (!isset($item['Descriere'])) {
                    $item['Descriere'] = '';
                }
            
                // Get the variation attributes
                $variation_attributes = $product->get_variation_attributes();
            
                // Loop through each selected attribute
                foreach ($variation_attributes as $attribute_taxonomy => $term_slug) {
                    // Get product attribute name or taxonomy
                    $taxonomy = str_replace('attribute_', '', $attribute_taxonomy);
            
                    // The label name from the product attribute
                    $attribute_name = wc_attribute_label($taxonomy, $product);
            
                    // The term name (or value) from this attribute
                    if (taxonomy_exists($taxonomy)) {
                        $term = get_term_by('slug', $term_slug, $taxonomy);
                        $attribute_value = $term ? $term->name : $term_slug;
                    } else {
                        $attribute_value = $term_slug; // For custom product attributes
                    }
            
                    if (isset($attribute_name) && !empty($attribute_name)
                        && isset($attribute_value) && !empty($attribute_value)) {
                        $item['Descriere'] .= $attribute_name . ': ' . $attribute_value . ' ';
                    }
                }
            }

            $pretDeBaza = $product->get_regular_price(); //pretul de baza, in cazul in care exista si pret special pe articol
            $pretCart =  $item_data['subtotal'] +  $item_data['subtotal_tax']; //pretul din pagina de comanda

            //verificare bifa
            if(get_option('wc_settings_tab_fgo_discount_invoice') == '1' && $pretCart / $item_data['quantity'] < $pretDeBaza){
                $item['PretTotal'] = $pretDeBaza * $item_data['quantity'];
            }
            else{
                $item['PretTotal'] =  $pretCart;
            }

            if($item['PretTotal'] < 0.00){
                $item['PretTotal'] = abs($item['PretTotal']);
                $item['NrProduse'] = -1 *  $item_data['quantity'];
            }
                     
            if ($item_data['subtotal'] == 0)
                $tva = 0;
            else
            { 
                $subtotal_tax_raw = $item_data['subtotal_tax'];
                $tva = ((($item_data['subtotal'] + $subtotal_tax_raw) / $item_data['subtotal'])-1)*100;
                $tva = round($tva);
                // fixes
                if ($tva != 0 && $tva != 5 && $tva != 9 && $tva != 11 && $tva != 21)
                {
                    $tva = CONFIG::closestVATRate($tva);
                }
            }
			if (is_nan($tva)) $tva = 0;
            $item['CotaTVA'] = $tva;

            $item['UM'] = CONFIG::$FGO_UM;
            $codGestiune = get_option('wc_settings_tab_fgo_product_management') != null ? get_option('wc_settings_tab_fgo_product_management') : null;
            $item['CodGestiune'] = $codGestiune;
            array_push($data['Continut'], $item);

            if(get_option('wc_settings_tab_fgo_discount_invoice') == '1' && $pretDeBaza != null && $pretCart / $item_data['quantity'] < $pretDeBaza){
                $valoareReducere = number_format($pretDeBaza * $item_data['quantity'] - $pretCart, 2 , '.', ''); //pretCart = e pretul total (pret produs * nrProduse); pretDeBaza este pretul produsului

                if($valoareReducere > 0.00){
                    $codArticolReducereArticol = get_option('wc_settings_tab_fgo_discount_mapping') != null ? get_option('wc_settings_tab_fgo_discount_mapping') : null;

                    array_push($data['Continut'], array(
                        'Denumire' => 'Reducere '.$item['Denumire'],
                        'CodArticol' => $codArticolReducereArticol,
                        'PretTotal' => $valoareReducere,
                        'UM' => 'H87',
                        'NrProduse' => - 1 * $item_data['quantity'],
                        'CotaTVA' => $tva,
                        'CodGestiune' => $codGestiune
                    ));
                }
            }

        }

        // Get order total discount
        $order_discount_total = $order->get_discount_total() + $order->get_discount_tax() ;
        if ($order_discount_total > 0)
        {
            $codArticolReducere = get_option('wc_settings_tab_fgo_discount_mapping') != null ? get_option('wc_settings_tab_fgo_discount_mapping') : null;
            // Get the correct number format (2 decimals) modificat - se calculeaza cu 2 zecimale
            $order_discount_total = number_format( $order_discount_total, 2 , '.', '');

            array_push($data['Continut'], array(
                    'Denumire' => 'Reducere',
                    'CodArticol' => $codArticolReducere,
                    'PretTotal' => $order_discount_total,
                    'UM' => 'H87',
                    'NrProduse' => -1,
                    'CotaTVA' => $tva,
                    'CodGestiune' => $codGestiune
                ));
        }

        foreach( $order->get_items('fee') as $item_id => $item_fee ){

            // The fee name
            $fee_name = $item_fee->get_name();

            // The fee total amount
            $fee_total = $item_fee->get_total();

            // The fee total tax amount
            $fee_total_tax = $item_fee->get_total_tax();

            // Get the correct number format (2 decimals) modificat - se calculeaza cu 2 zecimale
            $fee_total = number_format( $fee_total, 2 , '.', '');

            $fee_vat  = round(((($fee_total + $fee_total_tax) / $fee_total)-1)*100);

            $nrTax = 1;
            if($fee_total < 0.00)
            {
                $fee_total = abs($fee_total);
                $fee_total_tax = abs($fee_total_tax);
                $nrTax = -1;
            }

            array_push($data['Continut'], array(
                    'Denumire' => $fee_name,
                    'PretTotal' => $fee_total + $fee_total_tax,
                    'UM' => 'H87',
                    'NrProduse' => $nrTax,
                    'CotaTVA' => $fee_vat,
                    'CodGestiune' => $codGestiune
                ));
        }

        if (get_option('wc_settings_tab_fgo_insert_shipping') == '1')
        {
            $codGestiuneLivrare = get_option('wc_settings_tab_fgo_product_management') != null ? get_option('wc_settings_tab_fgo_product_management') : null;
            $codArticolLivrare = get_option('wc_settings_tab_fgo_shipping_mapping') != null ? get_option('wc_settings_tab_fgo_shipping_mapping') : null;
            $shipping = $order->get_shipping_total();

            $shipping_excl = $order->get_shipping_total();
            $shipping_tax  = $order->get_shipping_tax();
            $shipping_incl = $shipping_excl + $shipping_tax;


            if ($shipping > 0)
            {
                $tva = 0;

                if (get_option('wc_settings_tab_fgo_shipping_vat') == '1')
                {
                    $today = new DateTime();
                    $tva = ($today >= new DateTime('2025-08-01')) ? 21 : 19;
                }

                $tipPret = "PretTotal";
                $pretTransport = number_format((float)$shipping_incl, 2);
                if(get_option('wc_settings_tab_fgo_shipping_vat_type') == 0)
                {
                    $tipPret = "PretUnitar";
                    $pretTransport = number_format((float)$shipping, 4);
                }

                if(get_option('wc_settings_tab_fgo_product_management_shipping') != null)
                    $codGestiuneLivrare = get_option('wc_settings_tab_fgo_product_management_shipping');

                array_push($data['Continut'], array(
                    'Denumire' => 'Cost transport',
                    'CodArticol' => $codArticolLivrare,
                    $tipPret => $pretTransport,
                    'UM' => 'SX',
                    'NrProduse' => 1,
                    'CotaTVA' => $tva,
                    'CodGestiune' => $codGestiuneLivrare
                ));
            }
        }

        $refound_amount = $order->get_total_refunded();
        if ($refound_amount <> 0)
        {
            $codGestiune = get_option('wc_settings_tab_fgo_product_management') != null ? get_option('wc_settings_tab_fgo_product_management') : null;
            $motiv = 'Rambursare';

            array_push($data['Continut'], array(
                'Denumire' => $motiv,
                'PretTotal' => abs($refound_amount),
                'UM' => 'H87',
                'NrProduse' => -1,
                'CotaTVA' => $tva,
                'CodGestiune' => $codGestiune
            ));
        }

        $root = CONFIG::$FGO_SANDBOX_ROOT;
        if (get_option('wc_settings_tab_fgo_sandbox') == '0') {
            $root = CONFIG::$FGO_ROOT;
        }
        $url = $root . 'factura/emitere';

        // --- JSON payload (avoid ASP.NET Request.Form request validation) ---
        $requestId = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );

        $jsonPayload = array(
            'Text' => isset($data['Text']) ? $data['Text'] : null,
            'Explicatii' => isset($data['Explicatii']) ? $data['Explicatii'] : null,
            'Valuta' => isset($data['Valuta']) ? $data['Valuta'] : null,
            'TipFactura' => isset($data['TipFactura']) ? $data['TipFactura'] : null,
            'Serie' => isset($data['Serie']) ? $data['Serie'] : null,
            'Numar' => null,
            'TvaLaIncasare' => null,
            'IdExtern' => isset($data['IdExtern']) ? $data['IdExtern'] : null,
            'AWB' => null,
            'Continut' => isset($data['Continut']) ? $data['Continut'] : array(),
            'Client' => array(
                'CodUnic' => isset($data['Client[CodUnic]']) ? $data['Client[CodUnic]'] : null,
                'Denumire' => isset($data['Client[Denumire]']) ? $data['Client[Denumire]'] : null,
                'NrRegCom' => isset($data['Client[NrRegCom]']) ? $data['Client[NrRegCom]'] : null,
                'Email' => isset($data['Client[Email]']) ? $data['Client[Email]'] : null,
                'Telefon' => isset($data['Client[Telefon]']) ? $data['Client[Telefon]'] : null,
                'Tara' => isset($data['Client[Tara]']) ? $data['Client[Tara]'] : null,
                'Judet' => isset($data['Client[Judet]']) ? $data['Client[Judet]'] : null,
                'Localitate' => isset($data['Client[Localitate]']) ? $data['Client[Localitate]'] : null,
                'Adresa' => isset($data['Client[Adresa]']) ? $data['Client[Adresa]'] : null,
                'Tip' => isset($data['Client[Tip]']) ? $data['Client[Tip]'] : null,
                'IdExtern' => isset($data['Client[IdExtern]']) ? $data['Client[IdExtern]'] : 0,
                'Strain' => isset($data['Client[Strain]']) ? $data['Client[Strain]'] : null,
                'ContBancar' => null,
                'PlatitorTVA' => isset($data['Client[PlatitorTVA]']) ? $data['Client[PlatitorTVA]'] : null,
            ),
            'VerificareDuplicat' => isset($data['VerificareDuplicat']) ? $data['VerificareDuplicat'] : null,
            'ValideazaCodUnicRo' => isset($data['ValideazaCodUnicRo']) ? $data['ValideazaCodUnicRo'] : null,
            'RequestId' => $requestId,
            'SolutieId' => null,
            'UserId' => null,
            'UserIdInt' => 0,
            'SolutieIdInt' => null,
            'TipContId' => null,
            'CodUnic' => isset($data['CodUnic']) ? $data['CodUnic'] : null,
            'Hash' => isset($data['Hash']) ? $data['Hash'] : null,
            'Platforma' => isset($data['Platforma']) ? $data['Platforma'] : null,
            'PlatformaUrl' => isset($data['PlatformaUrl']) ? $data['PlatformaUrl'] : null,
            'Versiune' => isset($data['Versiune']) ? $data['Versiune'] : null,
            'VersiuneAddon' => isset($data['VersiuneAddon']) ? $data['VersiuneAddon'] : null,
            'Token' => isset($data['Token']) ? $data['Token'] : null,
        );

        $jsonBody = wp_json_encode($jsonPayload, JSON_UNESCAPED_UNICODE);

        //$build_query = http_build_query($data);         
        
        $result = "";
        try{
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonBody);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Accept: application/json'
            ));
            $result = curl_exec($ch);

            curl_close($ch);
            $response = json_decode($result);

            if ($response->{'Success'})
            {
                update_post_meta( $order_id, '_fgo_invoice_link', $response->{'Factura'}->{'Link'} );
                update_post_meta( $order_id, '_fgo_invoice_number', $response->{'Factura'}->{'Numar'});
                update_post_meta( $order_id, '_fgo_invoice_series', $response->{'Factura'}->{'Serie'});
                update_post_meta( $order_id, '_fgo_invoice_payment', $response->{'Factura'}->{'LinkPlata'});
                update_post_meta( $_POST['post_id'], '_fgo_invoice_status', 'emisa' );
                if(get_option('wc_settings_tab_fgo_stock_management') == '1')
                {

                    if($response->{'InfoStoc'} != null && count($response->{'InfoStoc'}) > 0)
                    {
                        WC_FGO_Premium_Order::updateStockAfterInvoice($order, $response->{'InfoStoc'});
                    }
                }
            }
            else 
            {
                if (CONFIG::is_html($result) && strpos($result, 'Forbidden') !== false) {
                    return '{"Success":false, "Message":"Apelul a fost respins de catre FGO (cod: FGO001)"}';
                    exit;
                }
            }
            update_option('wc_settings_tab_fgo_last_api_call',date('Y-m-d H:i:s.u'));
            return $result;
            exit;
        }
        catch(Exception $e){
            if (CONFIG::is_html($result) && strpos($result, 'Forbidden') !== false) {
                return '{"Success":false, "Message":"Apelul a fost respins de catre FGO (cod: FGO001)"}';
            }
            return '{"Success":false, "Message":"'.$e->$e->getMessage().'"}';
            exit;
        }
    }

    public static function init() {
        // Adding Meta container admin shop_order pages
		add_action( 'add_meta_boxes', 'mv_add_meta_boxes' );
		if ( ! function_exists( 'mv_add_meta_boxes' ) )
		{
			function mv_add_meta_boxes()
			{
                $screen = wc_get_container()->get( CustomOrdersTableController::class )->custom_orders_table_usage_is_enabled()
                    ? wc_get_page_screen_id( 'shop-order' )
                    : 'shop_order';

                wp_enqueue_script( 'fgo-script', plugin_dir_url( __FILE__ ) . 'assets/js/fgo-premium-order.js', array ( 'jquery' ), 1.1, true);
				add_meta_box( 'woocommerce-fgo-premium', __('FGO','woocommerce'), 'mv_add_other_fields_for_fgo', $screen, 'side', 'core' );
			}
		}
		// Adding Meta field in the meta container admin shop_order pages
		if ( ! function_exists( 'mv_add_other_fields_for_fgo' ) )
		{
			    function mv_add_other_fields_for_fgo( $order )
			    {
				global $post;
                $order_id_or_post_id = $post == null ? $order->get_id() : $post->ID;

                $invoice_type = get_option('wc_settings_tab_fgo_invoice_type');
                // Helper for labels
                function fgo_invoice_label($type, $default = 'Factura') {
                    switch ($type) {
                        case 'notice': return 'Aviz';
                        case 'order':  return 'Proforma';
                        case 'comanda': return 'Comanda';
                        default: return $default;
                    }
                }
                $label = fgo_invoice_label($invoice_type);

                $params = array(
                    'ajax_url' => admin_url('admin-ajax.php', 'woocommerce_admin_meta_boxes_fgo_premium'),
                    'ajax_nonce' => wp_create_nonce('fgo_field_nonce'),
                    'post_id' => $order_id_or_post_id
                );
                wp_localize_script( 'fgo-script', 'woocommerce_admin_meta_boxes_fgo_premium', $params );

                $meta_invoice_link = get_post_meta( $order_id_or_post_id, '_fgo_invoice_link', true ) ? get_post_meta( $order_id_or_post_id, '_fgo_invoice_link', true ) : '';
                $meta_invoice_number = get_post_meta( $order_id_or_post_id, '_fgo_invoice_number', true ) ? get_post_meta( $order_id_or_post_id, '_fgo_invoice_number', true ) : '';
                $meta_invoice_series = get_post_meta( $order_id_or_post_id, '_fgo_invoice_series', true ) ? get_post_meta( $order_id_or_post_id, '_fgo_invoice_series', true ) : '';
                $meta_invoice_status = get_post_meta( $order_id_or_post_id, '_fgo_invoice_status', true ) ? get_post_meta( $order_id_or_post_id, '_fgo_invoice_status', true ) : '';
                $meta_invoice_payment = get_post_meta( $order_id_or_post_id, '_fgo_invoice_payment', true ) ? get_post_meta( $order_id_or_post_id, '_fgo_invoice_payment', true ) : '';
                $meta_invoice_awb = get_post_meta($order_id_or_post_id, '_fgo_invoice_awb', true) ? get_post_meta($order_id_or_post_id, '_fgo_invoice_awb', true)	: '';

                $fgo_is_working = get_option('wc_settings_tab_fgo_is_working');

                if($fgo_is_working == '' || $fgo_is_working  == '0'){
                    echo '<p><b><font color="red">Asigura-te ca ai configurat corect setarile FGO! Intra in Woocommerce->setari->fgo si salveaza din nou setarile!</font></b></p>';
                }
                else if (empty($meta_invoice_link))
                {
                    if ($meta_invoice_status == 'anulata') {
                        echo '<ul class="order_notes"><li class="note system-note"><div class="note_content"><p>' . $label . ' a fost anulata' . '</p></div></li></ul>';
                    }
                    else if ($meta_invoice_status == 'stornata') {
                        echo '<ul class="order_notes"><li class="note system-note"><div class="note_content"><p>' . $label . ' a fost stornata' . '</p></div></li></ul>';
                    }
                    else if ($meta_invoice_status == 'stearsa') {
                        echo '<ul class="order_notes"><li class="note system-note"><div class="note_content"><p>' . $label . ' a fost stersa' . '</p></div></li></ul>';
                    }
                    else {
                        echo '<p style="border-bottom:solid 1px #eee;padding-bottom:13px;text-align:center;">
                                <button type="button" class="fgo_create_invoice button">Genereaza ' . $label . '</button>
                            </p>';
                    }
                }
                else
                {
                    echo '<p style="border-bottom:solid 1px #eee;padding-bottom:13px;text-align:center;">
                        <a href="' . $meta_invoice_link . '" target="_blank" class="button">Vizualizare ' . $label . ' ' . $meta_invoice_series . $meta_invoice_number . '</a> <br>
                        <a href="#" class="fgo_cancel_invoice">Anuleaza ' . $label . '</a> &nbsp;&nbsp; <a href="#" class="fgo_delete_invoice">Sterge ' . $label . '</a>';
                    if ($invoice_type !== 'comanda') {
                        echo '&nbsp;&nbsp; <a href="#" class="fgo_storno_invoice">Storneaza ' . $label . '</a>';
                    }
                    echo '</p>';

                    if(!empty($meta_invoice_payment)){
                        echo'<p>Link plata:
                        <input type="text" disabled value="' . $meta_invoice_payment . '"><br>
                        </p>';
                    }
                    echo'<p>AWB: <span class="fgo_awb_existent">' . $meta_invoice_awb . '</span><a href="#" class="fgo_awb"> Adauga/Modifica AWB</a></p>';
                }
			}
		}

        add_action('wp_ajax_woocommerce_fgo_create_invoice', 'woocommerce_fgo_create_invoice');
        add_action('wp_ajax_nopriv_woocommerce_fgo_create_invoice', 'woocommerce_fgo_create_invoice');
        if ( ! function_exists( 'woocommerce_fgo_create_invoice' ) )
        {
            WC_FGO_Premium_Order::createInvoice();
        }

        add_action('wp_ajax_woocommerce_fgo_cancel_invoice', 'woocommerce_fgo_cancel_invoice');
        add_action('wp_ajax_nopriv_woocommerce_fgo_cancel_invoice', 'woocommerce_fgo_cancel_invoice');
        if ( ! function_exists( 'woocommerce_fgo_cancel_invoice' ) )
        {
            WC_FGO_Premium_Order::cancelInvoice();
        }

		add_action('wp_ajax_woocommerce_fgo_delete_invoice', 'woocommerce_fgo_delete_invoice');
        add_action('wp_ajax_nopriv_woocommerce_fgo_delete_invoice', 'woocommerce_fgo_delete_invoice');
        if ( ! function_exists( 'woocommerce_fgo_delete_invoice' ) )
        {
            WC_FGO_Premium_Order::deleteInvoice();
        }

        add_action('wp_ajax_woocommerce_fgo_storno_invoice', 'woocommerce_fgo_storno_invoice');
        add_action('wp_ajax_nopriv_woocommerce_fgo_storno_invoice', 'woocommerce_fgo_storno_invoice');
        if ( ! function_exists( 'woocommerce_fgo_storno_invoice' ) )
        {
            WC_FGO_Premium_Order::stornoInvoice();
        }

        add_action('wp_ajax_woocommerce_fgo_add_awb', 'woocommerce_fgo_add_awb');
        add_action('wp_ajax_nopriv_woocommerce_fgo_add_awb', 'woocommerce_fgo_add_awb');
        if ( ! function_exists( 'woocommerce_fgo_add_awb' ) )
        {
            WC_FGO_Premium_Order::addAWB();
        }

        //   add_action( 'woocommerce_thankyou', 'OnPlacedOrder' );
        //  add_action( 'wp_ajax_nopriv_woocommerce_thankyou', 'OnPlacedOrder' );
        add_action( 'woocommerce_order_status_processing', 'fgo_woocommerce_order_status_processing' );

        function fgo_woocommerce_order_status_processing( $order_id ) {
            // Get an instance of the WC_Order Object
            $order = wc_get_order( $order_id );

            if( !in_array( $order->get_status(), ['failed'] ) ) {
                $fgo_is_working = get_option('wc_settings_tab_fgo_is_working');
                if ($fgo_is_working != '' && $fgo_is_working == 1 && get_option('wc_settings_tab_fgo_api_call') == 'onOrder'){
                    if (!get_post_meta($order_id, '_fgo_invoice_link', true )){
                        $lastApiCall = get_option('wc_settings_tab_fgo_last_api_call');

                        if($lastApiCall != null && strtotime(date('Y-m-d H:i:s.u')) - strtotime($lastApiCall) < 1)
                        {
                            sleep(1);
                        }

                        WC_FGO_Premium_Order::buildFactura($order_id);
                    }
                }
            }
        }

        add_action( 'woocommerce_order_status_completed', 'fgo_woocommerce_order_status_completed' );

        function fgo_woocommerce_order_status_completed($order_id){
            // Get an instance of the WC_Order Object
            $order = wc_get_order( $order_id );

            if( !in_array( $order->get_status(), ['failed','pending'] ) ) {
                $fgo_is_working = get_option('wc_settings_tab_fgo_is_working');
                if ($fgo_is_working != '' && $fgo_is_working == 1 && get_option('wc_settings_tab_fgo_api_call') == 'onCompleted'){
                    if (!get_post_meta($order_id, '_fgo_invoice_link', true )){

                        $lastApiCall = get_option('wc_settings_tab_fgo_last_api_call');

                        if($lastApiCall != null && strtotime(date('Y-m-d H:i:s.u')) - strtotime($lastApiCall) < 1)
                        {
                            sleep(1);
                        }

                        WC_FGO_Premium_Order::buildFactura($order_id);
                    }
                }
            }
        }

        add_action( 'woocommerce_payment_complete', 'fgo_woocommerce_payment_complete' );

        function fgo_woocommerce_payment_complete($order_id){
            // Get an instance of the WC_Order Object
            $order = wc_get_order( $order_id );

            if( !in_array( $order->get_status(), ['failed','pending'] ) ) {
                $fgo_is_working = get_option('wc_settings_tab_fgo_is_working');
                if ($fgo_is_working != '' && $fgo_is_working == 1 && get_option('wc_settings_tab_fgo_api_call') == 'onPayment'){
                    if (!get_post_meta($order_id, '_fgo_invoice_link', true )){

                        $lastApiCall = get_option('wc_settings_tab_fgo_last_api_call');

                        if($lastApiCall != null && strtotime(date('Y-m-d H:i:s.u')) - strtotime($lastApiCall) < 1)
                        {
                            sleep(1);
                        }

                        WC_FGO_Premium_Order::buildFactura($order_id);
                    }
                }
            }
        }
    }

    public static function createInvoice(){
		/*function custom_content_thankyou( $order_id ) {
        woocommerce_fgo_create_invoice($order_id );
		}	*/
        function woocommerce_fgo_create_invoice()
        {
            if (check_ajax_referer( 'fgo_field_nonce', 'security' ))
            {
                $order_id = $_POST['post_id'];

                $lastApiCall = get_option('wc_settings_tab_fgo_last_api_call');

                if($lastApiCall != null && strtotime(date('Y-m-d H:i:s.u')) - strtotime($lastApiCall) < 1)
                {
                    sleep(1);
                }

                $result = WC_FGO_Premium_Order::buildFactura($order_id);
                echo $result;

                exit;
            }
        }

        function formatted_billing_address($order)
        {
            return
                $order->get_billing_address_1() . ', ' .
                $order->get_billing_address_2() . ' ' .
                $order->get_billing_state()  . ' ' .
                $order->get_billing_postcode();
        }
    }

    public static function cancelInvoice(){
        function woocommerce_fgo_cancel_invoice()
        {
            if (check_ajax_referer( 'fgo_field_nonce', 'security' ))
            {
                $root = CONFIG::$FGO_SANDBOX_ROOT;
                $key = "4C490B5C";
                if (get_option('wc_settings_tab_fgo_sandbox') == '0') {
                    $root = CONFIG::$FGO_ROOT;
                }
                $url = $root . 'factura/anulare';
                $data = array();

                $codUnic = get_option('wc_settings_tab_fgo_client_code');
                $privateKey = get_option('wc_settings_tab_fgo_private_key');
                $meta_invoice_number = get_post_meta( $_POST['post_id'], '_fgo_invoice_number', true ) ? get_post_meta( $_POST['post_id'], '_fgo_invoice_number', true ) : '';
                $meta_invoice_series = get_post_meta( $_POST['post_id'], '_fgo_invoice_series', true ) ? get_post_meta( $_POST['post_id'], '_fgo_invoice_series', true ) : '';

                $data['CodUnic'] = $codUnic;
                $data['Hash'] = strtoupper(SHA1($codUnic . $privateKey . $meta_invoice_number));
                $data['Serie'] = $meta_invoice_series;
                $data['Numar'] = $meta_invoice_number;
                $data['Platforma'] = CONFIG::$FGO_PLATFORMA;
                $site_name = CONFIG::fgo_get_site_url();
                if ($site_name == '')
                    $data['PlatformaUrl'] = get_option('wc_settings_tab_fgo_site_url');
                else $data['PlatformaUrl'] = $site_name;
                $data['Versiune'] = WC()->version;
                $data['VersiuneAddon'] = CONFIG::$FGO_VERSIUNE_MODUL;
                $token = strtoupper(SHA1( $meta_invoice_series . $meta_invoice_number . $key));
                $data['Token'] = $token;

                //CONFIG::logRequest($_POST, $data);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $result = curl_exec($ch);
                echo $result;
                curl_close($ch);
                $response = json_decode($result);

                if ($response->{'Success'})
                {
                    update_post_meta( $_POST['post_id'], '_fgo_invoice_status', 'anulata' );
                    update_post_meta( $_POST['post_id'], '_fgo_invoice_link', '' );
                    update_post_meta( $_POST['post_id'], '_fgo_invoice_number', '');
                    update_post_meta( $_POST['post_id'], '_fgo_invoice_series', '');
                }
                //  echo $result;
                exit;
            }
        }
    }

	public static function deleteInvoice(){
        function woocommerce_fgo_delete_invoice()
        {
            if (check_ajax_referer( 'fgo_field_nonce', 'security' ))
            {
                $root = CONFIG::$FGO_SANDBOX_ROOT;
                $key = "4C490B5C";
                if (get_option('wc_settings_tab_fgo_sandbox') == '0') {
                    $root = CONFIG::$FGO_ROOT;
                }
                $url = $root . 'factura/stergere';
                $data = array();

                $codUnic = get_option('wc_settings_tab_fgo_client_code');
                $privateKey = get_option('wc_settings_tab_fgo_private_key');
                $meta_invoice_number = get_post_meta( $_POST['post_id'], '_fgo_invoice_number', true ) ? get_post_meta( $_POST['post_id'], '_fgo_invoice_number', true ) : '';
                $meta_invoice_series = get_post_meta( $_POST['post_id'], '_fgo_invoice_series', true ) ? get_post_meta( $_POST['post_id'], '_fgo_invoice_series', true ) : '';

                $data['CodUnic'] = $codUnic;
                $data['Hash'] = strtoupper(SHA1($codUnic . $privateKey . $meta_invoice_number));
                $data['Serie'] = $meta_invoice_series;
                $data['Numar'] = $meta_invoice_number;
                $data['Platforma'] = CONFIG::$FGO_PLATFORMA;
                $site_name = CONFIG::fgo_get_site_url();
                if ($site_name == '')
                    $data['PlatformaUrl'] = get_option('wc_settings_tab_fgo_site_url');
                else $data['PlatformaUrl'] = $site_name;
                $data['Versiune'] = WC()->version;
                $data['VersiuneAddon'] = CONFIG::$FGO_VERSIUNE_MODUL;
                $token = strtoupper(SHA1( $meta_invoice_series . $meta_invoice_number . $key));
                $data['Token'] = $token;

                //CONFIG::logRequest($_POST, $data);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $result = curl_exec($ch);
                echo $result;
                curl_close($ch);
                $response = json_decode($result);

                // if ($response->{'Success'})
                // {
                update_post_meta( $_POST['post_id'], '_fgo_invoice_status', 'stearsa' );
                update_post_meta( $_POST['post_id'], '_fgo_invoice_link', '' );
                update_post_meta( $_POST['post_id'], '_fgo_invoice_number', '');
                update_post_meta( $_POST['post_id'], '_fgo_invoice_series', '');
                // }
                //echo $result;
                exit;
            }
        }
    }

    public static function stornoInvoice(){
        function woocommerce_fgo_storno_invoice()
        {
            if (check_ajax_referer( 'fgo_field_nonce', 'security' ))
            {
                $root = CONFIG::$FGO_SANDBOX_ROOT;
                $key = "4C490B5C";
                if (get_option('wc_settings_tab_fgo_sandbox') == '0') {
                    $root = CONFIG::$FGO_ROOT;
                }
                $url = $root . 'factura/stornare';
                $data = array();

                $codUnic = get_option('wc_settings_tab_fgo_client_code');
                $privateKey = get_option('wc_settings_tab_fgo_private_key');
                $meta_invoice_number = get_post_meta( $_POST['post_id'], '_fgo_invoice_number', true ) ? get_post_meta( $_POST['post_id'], '_fgo_invoice_number', true ) : '';
                $meta_invoice_series = get_post_meta( $_POST['post_id'], '_fgo_invoice_series', true ) ? get_post_meta( $_POST['post_id'], '_fgo_invoice_series', true ) : '';

                $data['CodUnic'] = $codUnic;
                $data['Hash'] = strtoupper(SHA1($codUnic . $privateKey . $meta_invoice_number));
                $data['Serie'] = $meta_invoice_series;
                $data['Numar'] = $meta_invoice_number;
                $data['Platforma'] = CONFIG::$FGO_PLATFORMA;
                $site_name = CONFIG::fgo_get_site_url();
                if ($site_name == '')
                    $data['PlatformaUrl'] = get_option('wc_settings_tab_fgo_site_url');
                else $data['PlatformaUrl'] = $site_name;
                $data['Versiune'] = WC()->version;
                $data['VersiuneAddon'] = CONFIG::$FGO_VERSIUNE_MODUL;
                $token = strtoupper(SHA1( $meta_invoice_series . $meta_invoice_number . $key));
                $data['Token'] = $token;

               // CONFIG::logRequest($_POST, $data);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $result = curl_exec($ch);
                echo $result;
                curl_close($ch);
                $response = json_decode($result);

                if ($response->{'Success'})
                {
                    update_post_meta( $_POST['post_id'], '_fgo_invoice_status', 'stornata' );
                    update_post_meta( $_POST['post_id'], '_fgo_invoice_link', '' );
                    update_post_meta( $_POST['post_id'], '_fgo_invoice_number', '');
                    update_post_meta( $_POST['post_id'], '_fgo_invoice_series', '');
                }
                //echo $result;
                exit;
            }
        }
    }

    public static function addAWB(){
        function woocommerce_fgo_add_awb()
        {
            if (check_ajax_referer( 'fgo_field_nonce', 'security' ))
            {
                $root = CONFIG::$FGO_SANDBOX_ROOT;
                if (get_option('wc_settings_tab_fgo_sandbox') == '0') {
                    $root = CONFIG::$FGO_ROOT;
                }
                $url = $root . 'factura/awb';
               
                $data = array();
                $key = "4C490B5C";

                $codUnic = get_option('wc_settings_tab_fgo_client_code');
                $privateKey = get_option('wc_settings_tab_fgo_private_key');
                $meta_invoice_number = get_post_meta( $_POST['post_id'], '_fgo_invoice_number', true ) ? get_post_meta( $_POST['post_id'], '_fgo_invoice_number', true ) : '';
                $meta_invoice_series = get_post_meta( $_POST['post_id'], '_fgo_invoice_series', true ) ? get_post_meta( $_POST['post_id'], '_fgo_invoice_series', true ) : '';

                $data['CodUnic'] = $codUnic;
                $data['Hash'] = strtoupper(SHA1($codUnic . $privateKey . $meta_invoice_number));
                $data['Serie'] = $meta_invoice_series;
                $data['Numar'] = $meta_invoice_number;
                $data['Platforma'] = CONFIG::$FGO_PLATFORMA;
                $site_name = CONFIG::fgo_get_site_url();
                if ($site_name == '')
                    $data['PlatformaUrl'] = get_option('wc_settings_tab_fgo_site_url');
                else $data['PlatformaUrl'] = $site_name;
                $data['Versiune'] = WC()->version;
                $data['VersiuneAddon'] = CONFIG::$FGO_VERSIUNE_MODUL;
                $token = strtoupper(SHA1( $meta_invoice_series . $meta_invoice_number . $key));
                $data['Token'] = $token;
                $data['AWB'] = $_POST['awb'];

               // CONFIG::logRequest($_POST, $data);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $result = curl_exec($ch);
                echo $result;
                curl_close($ch);
                $response = json_decode($result);

                if ($response->{'Success'})
                {
                    update_post_meta( $_POST['post_id'], '_fgo_invoice_awb', $data['AWB']);
                }
                echo $result;
                exit;
            }
        }
    }

    public static function updateStockAfterInvoice($order, $infoStoc){
        foreach ($order->get_items() as $item) {
            //sku
            $product_id = $item->get_product_id();
            $product_name = $item->get_name(); 
            $product = wc_get_product($product_id);
            $product_sku = $product->get_sku();

            // Property to search for
            $searchByCodConta = 'CodConta';
            $searchByNume = 'Nume';
            $searchValue = $product_sku;
            $searchProductName = $product_name;

            // Iterate over the array to find the item2
            $foundItem = null;
            foreach ($infoStoc as $item2) {
                if (isset($item2->$searchByCodConta) && $item2->$searchByCodConta === $searchValue) {
                    $foundItem = $item2;
                    break; // Found the item, exit the loop
                }
            }
            if($foundItem->$searchByCodConta == null){
                foreach ($infoStoc as $item2) {
                    if (isset($item2->$searchByNume) && $item2->$searchByNume === $searchProductName) {
                        $foundItem = $item2;
                        break; // Found the item, exit the loop
                    }
                }
            }

            if($foundItem != null){                              
                    $woocmmerce_instance = new WC_Product( $product_id );
                    $new_quantity=wc_update_product_stock( $woocmmerce_instance, $foundItem->Stoc);
              }
        }
    }
}