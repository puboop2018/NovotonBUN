<?php
if (!defined('ABSPATH')) {
    exit;
}

class WC_FGO_Billing
{

    public static function init()
    {

        add_filter('woocommerce_billing_fields', 'addVATFields');
        add_action('woocommerce_checkout_process', 'validate_VAT');
        add_action('woocommerce_checkout_update_order_meta', 'vat_checkout_field_update_order_meta');
        add_filter('woocommerce_admin_order_buyer_name', 'override_order_buyer_name', 10, 2);

        add_action('woocommerce_order_details_after_customer_details', 'fgo_display_company_info_on_view_order', 10);

         function fgo_display_company_info_on_view_order($order) {
            if (!$order instanceof WC_Order) return;

            $tip_facturare = $order->get_meta('_billing_tip_facturare');
            $cui = $order->get_meta('woocommerce_fgo_billing_cui');
            $company = $order->get_billing_company();
            if (empty($company)) {
                $company = $order->get_meta('woocommerce_fgo_billing_company');
            }

            if ($tip_facturare === '1') {
                echo '<section class="woocommerce-columns woocommerce-columns--2 woocommerce-columns--addresses col2-set addresses">';
                echo '<div class="woocommerce-column woocommerce-column--1 woocommerce-column--billing-address col-1">';
                echo '<h2 class="woocommerce-column__title">' . __('Date companie', 'woocommerce') . '</h2>';
                echo '<address>';
                echo '<strong>' . __('Tip persoană:', 'woocommerce') . '</strong> juridică<br/>';
                echo '<strong>' . __('Nume: ', 'woocommerce') . '</strong>' . esc_html($company) . '<br/>';
                if ($cui) {
                    echo '<strong>' . __('CUI:', 'woocommerce') . '</strong> ' . esc_html($cui) . '<br/>';
                }
                echo '</address>';
                echo '</div>';
                echo '</section>';
            }
        }

        add_action('woocommerce_email_after_order_table', 'fgo_add_company_info_to_email', 10, 4);
        function fgo_add_company_info_to_email($order, $sent_to_admin, $plain_text, $email) {
            if (!$order instanceof WC_Order) return;
        
            $tip = $order->get_meta('_billing_tip_facturare');
            $cui = $order->get_meta('woocommerce_fgo_billing_cui');
            $company = $order->get_billing_company();
            if (empty($company)) {
                $company = $order->get_meta('woocommerce_fgo_billing_company');
            }
            if ($tip === '1') {
                echo '<h2>' . __('Date facturare', 'woocommerce') . '</h2>';
                echo '<address>';
                echo '<strong>' . __('Tip persoană:', 'woocommerce') . '</strong> juridică<br/>';
                if ($cui) {
                    echo '<strong>' . __('Nume:', 'woocommerce') . '</strong> ' . esc_html($company) . '<br/>';
                    echo '<strong>' . __('CUI:', 'woocommerce') . '</strong> ' . esc_html($cui) . '<br/>';
                }
                echo '<br/>';
                echo '</address>';
            }
        }

        
        function override_order_buyer_name($buyer, $order) {
            $company = $order->get_billing_company();
            $tip_facturare = $order->get_meta('_billing_tip_facturare');
        
            if ($company && $tip_facturare === '1') {
                return $company;
            }
        
            return $buyer; // fallback la comportamentul implicit
        }
       
        /*
        add_action('woocommerce_customer_save_address', 'save_custom_invoicing_field', 10, 2);

        function save_custom_invoicing_field($user_id, $address_type) {
            // Check if the address being updated is billing
            if ($address_type === 'billing') {
                // Sanitize and save your custom field value
                if (isset($_POST['billing_cui'])) {
                    update_user_meta($user_id, 'woocommerce_fgo_billing_cui', sanitize_text_field($_POST['woocommerce_fgo_billing_cui']));
                    
                }
            }
        }
        */

        function addVATFields($fields)
        {
            if (get_option('wc_settings_tab_fgo_client_vat') == '1' && get_option('wc_settings_tab_fgo_client_vat_fgo') == '1') {
                $fields['billing_tip_facturare'] = array(
                            'name' => __('woocommerce_fgo_billing_tip_facturare', 'woocommerce-order-billing-tip-facturare-fgo'),
                            'type' => 'select',
                            'options' => array(
                                '1' => __('Persoana Juridica', 'woocommerce'),
                                '2' => __('Persoana Fizica', 'woocommerce')
                            ),
                            'id' => 'wc_order_billing_tip_facturare_fgo_client',
                            'label' => __('Tip Facturare', 'woocommerce'),
                            'css' => 'min-width: 350px;',
                            'class' => 'wc-enhanced-select',
                            'required' => true,
                            'default' => '2',
                            'priority' => 0
                      );

                $fields['billing_cui'] = array(
                    'name' => __('woocommerce_fgo_billing_cui', 'woocommerce-order-billing-cui-fgo'),
                    'type' => 'text',
                    'id' => 'wc_order_billing_cui_fgo_client',
                    'label' => __('Cod Unic', 'woocommerce'),
                    'placeholder' => _x('CUI', 'placeholder', 'woocommerce'),
                    'required' => true,
                    'clear' => true,
                    'priority' => 6
                );
                $fields['billing_nr_reg_comertului'] = array(
                    'name' => __('woocommerce_fgo_nr_reg_comertului', 'woocommerce-order-nr-reg-comertului-fgo'),
                    'type' => 'text',
                    'id' => 'wc_order_nr_reg_comertului_fgo_client',
                    'label' => __('Nr reg comertului', 'woocommerce'),
                    'placeholder' => _x('Nr Registrul comertului', 'placeholder', 'woocommerce'),
                    'required' => false,
                    'clear' => true,
                    'priority' => 7
                );

                $fields['billing_company']['required'] = true;
                $fields['billing_company']['priority'] = 5;

                // Enqueue jQuery script to handle show/hide functionality
                add_action('wp_footer', 'custom_billing_fields_script');
            }

            return $fields;
        }

        function custom_billing_fields_script()
        {
            ?>
            <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    function checkTipFacturareFieldValue() {
                        var selectedValue = $('#wc_order_billing_tip_facturare_fgo_client').val();
                        
                        // daca e Persoana Juridica
                        if (selectedValue === '1') {
                            $('#wc_order_billing_cui_fgo_client_field label').html('<?php echo esc_js(__('Cod Unic', 'woocommerce')); ?>' + '<abbr class="required" title="<?php echo esc_attr(__('obligatoriu', 'woocommerce')); ?>"> *</abbr>');
                            $('#wc_order_billing_cui_fgo_client').attr('placeholder', '<?php echo esc_attr(__('CUI', 'woocommerce')); ?>');
                            $('#billing_company_field, #wc_order_nr_reg_comertului_fgo_client_field').show();
                            $('#billing_company_field, #wc_order_billing_cui_fgo_client_field').show();
                        } else if (selectedValue === '2') {
                            <?php
                            // Check if billing CUI is required
                            if (get_option('wc_settings_tab_fgo_client_cnp_obligatoriu') == '1') {
                                ?>
                                $('#wc_order_billing_cui_fgo_client_field label').html('<?php echo esc_js(__('CNP', 'woocommerce')); ?>' + '<abbr class="required" title="<?php echo esc_attr(__('obligatoriu', 'woocommerce')); ?>"> *</abbr>');
                                $('#wc_order_billing_cui_fgo_client').attr('placeholder', '<?php echo esc_attr(__('cnp', 'woocommerce')); ?>');
                            <?php } else { ?>
                                $('#wc_order_billing_cui_fgo_client_field label').text('<?php echo esc_js(__('CNP', 'woocommerce')); ?>');
                                $('#wc_order_billing_cui_fgo_client').attr('placeholder', '<?php echo esc_attr(__('cnp (optional)', 'woocommerce')); ?>');
                            <?php } ?>
                            $('#billing_company_field, #wc_order_billing_cui_fgo_client_field').show();
                            $('#billing_company_field, #wc_order_nr_reg_comertului_fgo_client_field').hide();
                            $('#billing_company_field, #wc_order_billing_cui_fgo_client_field, #wc_order_nr_reg_comertului_fgo_client_field').find('input').val('');
                        }
                        else {
                            $('#billing_company_field, #wc_order_nr_reg_comertului_fgo_client_field').hide();
                            $('#billing_company_field, #wc_order_billing_cui_fgo_client_field').hide();
                        }
                    }

                    checkTipFacturareFieldValue();

                    $('#wc_order_billing_tip_facturare_fgo_client').change(function () {
                        checkTipFacturareFieldValue();
                    });
                });
            </script>
            <?php
        }

        add_filter('woocommerce_billing_fields', 'ts_unrequire_wc_field');
        function ts_unrequire_wc_field($fields)
        {
            if (isset ($_POST['billing_tip_facturare']) && $_POST['billing_tip_facturare'] === '2') {
                $fields['billing_company']['required'] = false;
                $fields['billing_cui']['required'] = false;
                $fields['billing_nr_reg_comertului']['required'] = false;
            }

            if (get_option('wc_settings_tab_fgo_client_vat_fgo') == '1' && get_option('wc_settings_tab_fgo_client_cnp_obligatoriu') == '1') {
                $fields['billing_cui']['required'] = true;
            }

            return $fields;
        }


        function validate_VAT()
        {
            // Check if set, if it's not set add an error.
            if (get_option('wc_settings_tab_fgo_client_vat') == '1' && empty (get_option('wc_settings_tab_fgo_client_vat_field'))) {
                if (get_option('wc_settings_tab_fgo_client_vat_fgo') == '0') {
                    if (!empty ($_POST['billing_company']) && empty ($_POST['billing_cui']))
                        wc_add_notice('Introduceti CUI-ul.', 'error');
                }
            }
        }


        function vat_checkout_field_update_order_meta($order_id)
        {

            $nrRegCom = '';
            $vat = array_key_exists('billing_cui', $_POST) ? $_POST['billing_cui'] : '';
            $company = '';

            if (get_option('wc_settings_tab_fgo_client_vat_fgo') == '0') {
                $vat_input = get_option('wc_settings_tab_fgo_client_vat_field');
                $nrRegCom_input = get_option('wc_settings_tab_fgo_client_nrRegCom_field');
                $company_input = get_option('wc_settings_tab_fgo_client_firma_field');
                $cnp_input = get_option('wc_settings_tab_fgo_client_cnp_field');

                $vat = is_null($_POST[$vat_input]) ? '' : $_POST[$vat_input];
                $nrRegCom = is_null($_POST[$nrRegCom_input]) ? '' : $_POST[$nrRegCom_input];
                $company = is_null($_POST[$company_input]) ? '' : $_POST[$company_input];
                $cnp = is_null($_POST[$cnp_input]) ? '' : $_POST[$cnp_input];
                
                if ((!empty($_POST['tip_facturare']) && $_POST['tip_facturare'] == 'pers-fiz') || 
                    (!empty($_POST['curiero_pf_pj_type']) && $_POST['curiero_pf_pj_type'] == 'pers-fiz'))
                {
                    $vat = '';
                    $nrRegCom = '';
                    $company = '';
                }

                if (empty ($vat) && !empty ($cnp)) {
                    $vat = $cnp;
                }
            } else {
                if (array_key_exists('billing_cui', $_POST))
                    $vat = is_null($_POST['billing_cui']) ? '' : $_POST['billing_cui'];

                if (array_key_exists('billing_nr_reg_comertului', $_POST))
                    $nrRegCom = is_null($_POST['billing_nr_reg_comertului']) ? '' : $_POST['billing_nr_reg_comertului'];
                
                if (array_key_exists('billing_company', $_POST))
                    $company = is_null($_POST['billing_company']) ? '' : $_POST['billing_company'];
            }
            
            if (!empty($_POST['billing_tip_facturare'])) {
                update_post_meta($order_id, 'woocommerce_fgo_billing_tip_facturare', sanitize_text_field($_POST['billing_tip_facturare']));
            }
            // check_CUI($vat);
            update_post_meta($order_id, 'woocommerce_fgo_billing_cui', sanitize_text_field($vat));
            update_post_meta($order_id, 'woocommerce_fgo_billing_reg', sanitize_text_field($nrRegCom));
            update_post_meta($order_id, 'woocommerce_fgo_billing_company', sanitize_text_field($company));

            // daca se foloseste optiune HPSO
            $order = wc_get_order($order_id);
            $order->update_meta_data('woocommerce_fgo_billing_cui', sanitize_text_field($vat));
            $order->update_meta_data('woocommerce_fgo_billing_reg', sanitize_text_field($nrRegCom));
            $order->update_meta_data('woocommerce_fgo_billing_company', sanitize_text_field($company));
            $order->save();
        }

        add_action('woocommerce_admin_order_data_after_billing_address', 'add_custom_field_to_invoicing_section');
        function add_custom_field_to_invoicing_section($order) {
            // Retrieve the custom field value
            $woocommerce_fgo_billing_cui = get_post_meta($order->get_id(), 'woocommerce_fgo_billing_cui', true);
            $tip_facturare = get_post_meta($order->get_id(), '_billing_tip_facturare', true);

            if (empty($woocommerce_fgo_billing_cui)==false) 
            {
                $tip_persoana = $tip_facturare == "2" ? "fizica" : "juridica";
                ?>
                <div class='address'>
                    <p>
                        <strong><?php _e('Tip persoana:', 'woocommerce'); ?></strong>
                        <span><?php echo esc_html($tip_persoana); ?></span>
                    </p>
                    <p>
                        <strong><?php _e('Cod Unic:', 'woocommerce'); ?></strong>
                        <span id="custom_field_value"><?php echo esc_html($woocommerce_fgo_billing_cui ? $woocommerce_fgo_billing_cui : __('N/A', 'woocommerce')); ?></span>
                    </p>
                </div>
                <?php
                // Display the custom field as an editable input
                ?>
                 <div class='edit_address'>
                    <p class="form-field">
                        <label for="woocommerce_fgo_billing_tip_facturare"><strong><?php _e('Tip persoana:', 'woocommerce'); ?></strong></label>
                        <select id="woocommerce_fgo_billing_tip_facturare" name="woocommerce_fgo_billing_tip_facturare">
                            <option value="1" <?php echo esc_html($tip_facturare == 1 ? 'selected' : ''); ?>>Persoana juridica</option>
                            <option value="2" <?php echo esc_html($tip_facturare == 2 ? 'selected' : ''); ?>>Persoana fizica</option>
                        </select>
                    </p>
                    <p class="form-field">
                        <label for="woocommerce_fgo_billing_cui"><strong><?php _e('Cod Unic:', 'woocommerce'); ?></strong></label>
                        <input type="text" id="woocommerce_fgo_billing_cui" name="woocommerce_fgo_billing_cui" value="<?php echo esc_attr($woocommerce_fgo_billing_cui); ?>" class="short" />
                    </p>
                </div>
                <?php
            }
        }

        add_action('woocommerce_process_shop_order_meta', 'save_custom_field_on_order_save', 10, 2);
        function save_custom_field_on_order_save($order_id, $post) {
            if (isset($_POST['woocommerce_fgo_billing_cui'])) {
                // Sanitize and save the custom field value
                $cnp_field_value = sanitize_text_field($_POST['woocommerce_fgo_billing_cui']);
                update_post_meta($order_id, 'woocommerce_fgo_billing_cui', $cnp_field_value);
            }
            if (isset($_POST['woocommerce_fgo_billing_tip_facturare'])) {
                $tip_facturare_field_value = sanitize_text_field($_POST['woocommerce_fgo_billing_tip_facturare']);
                update_post_meta($order_id, '_billing_tip_facturare', $tip_facturare_field_value);
            }
        }

        // Save the editable field
        add_action('woocommerce_process_shop_order_meta', 'save_editable_custom_field');
        function save_editable_custom_field($order_id) {
            if (isset($_POST['woocommerce_fgo_billing_cui'])) {
                update_post_meta($order_id, 'woocommerce_fgo_billing_cui', sanitize_text_field($_POST['woocommerce_fgo_billing_cui']));
            }
        }
    }
}