<?php
if (!defined('ABSPATH')) {
    exit;
}

class WC_FGO_Client_Page {

    public static function init() {
        add_action('woocommerce_order_details_after_order_table', 'display_invoice_link_in_order_details');

        function display_invoice_link_in_order_details($order) {
            $invoice_link = get_post_meta( $order->get_id(), '_fgo_invoice_link', true );

            if ($invoice_link) {
                echo '<p><a href="' . esc_url($invoice_link) . '" target="_blank" class="button">' . __('Descarcă Factura', 'text-domain') . '</a></p>';
            }
        }
    }
}