jQuery(function ($) {

    $(document).ready(function(){

        var $rowExternalVatField = $(document).find("#wc_settings_tab_fgo_client_vat_field").closest("tr");
        var $rowExternalNrRegComField = $(document).find("#wc_settings_tab_fgo_client_nrRegCom_field").closest("tr");
        var $rowStockField = $(document).find("#wc_settings_tab_fgo_stock_management").closest("tr");
        var $rowItemDescField = $(document).find("#wc_settings_tab_fgo_product_description").closest("tr");
        var $rowSiteUrl = $(document).find("#wc_settings_tab_fgo_site_url").closest("tr");

        $rowExternalVatField.find("td").find(".description").append('<br /><p style="color:orange"><i class="dashicons dashicons-warning" style="color:orange"></i> Ia legatura cu persoana tehnica ce se ocupa de site/autorul pluginului extern pentru a-ti furniza <b>name-ul</b> input-ului din care doresti preluarea informatiei.</p>');
        $rowExternalNrRegComField.find("td").find(".description").append('<br /><p style="color:orange"><i class="dashicons dashicons-warning" style="color:orange"></i> Ia legatura cu persoana tehnica ce se ocupa de site/autorul pluginului extern pentru a-ti furniza <b>name-ul</b> input-ului din care doresti preluarea informatiei.</p>');
        $rowStockField.find("td").find(".description").append('<br /><p style="color:orange"><i class="dashicons dashicons-warning" style="color:orange"></i> Este necesar sa existe corespondent intre codurile din magazin si codurile de articol din FGO!</p>');
        $rowItemDescField.find("td").find(".description").append('<br /><p style="color:orange"><i class="dashicons dashicons-warning" style="color:orange"></i> Este necesar sa existe corespondent intre codurile din magazin si codurile de articol din FGO!</p>');
        $rowSiteUrl.find("td").find(".description").append('<p>(in caz ca valoarea afisata este 0, este necesar sa completati dvs adresa magazinului (ex https://www.magazin.ro), care va trebui sa corespunda cu adresa magazinului trecuta in sectiunea eCommerce -> setari API din FGO)</p>');

        var $rowSingleSeries =  $(document).find("#wc_settings_tab_fgo_invoice_series").closest("tr");
        var $tableDifferentSeries = $(document).find(".wc_settings_tab_fgo_invoice_series_roles").closest("table");
        var $tableDifferentDesc = $(document).find("#wc_settings_tab_fgo_section_title2-description");
        $tableDifferentDesc.css("font-size", "larger");
        $tableDifferentDesc.css("font-weight", "bolder");

        $rowSingleSeries.find("td").css("display", "flex");
        $tableDifferentSeries.find("td").css("display", "flex");

        $rowSingleSeries.find("td").css("display", "flex");
        $rowSingleSeries.find("td").find(".description").html('<br /><span style="color:orange"><i class="dashicons dashicons-warning" style="color:orange"></i> Este recomandat ca aceasta serie sa nu expire in FGO</span>');
        $tableDifferentSeries.find("td").find(".description").html('<br /><span style="color:orange"><i class="dashicons dashicons-warning" style="color:orange"></i> Este recomandat ca aceasta serie sa nu expire in FGO</span>');

        var $seriesTransmition = $('#wc_settings_tab_fgo_series_option');
        var $pluginExtern = $('#wc_settings_tab_fgo_client_vat_external');
        var $vatField = $('#wc_settings_tab_fgo_client_vat_field');
        var $nrRegComField = $('#wc_settings_tab_fgo_client_nrRegCom_field');

        if($seriesTransmition.val() != '0')
            $rowSingleSeries.hide();
        if($seriesTransmition.val() != '1'){
            $tableDifferentSeries.hide();
            $tableDifferentDesc.hide();
        }

        $('h2').each(function() {
            if ($(this).text() == "FGO: Setari Articole")
            {
                $('.form-table').find("tr").last().after("<tr><th><label class='titledesc'>Actualizeaza stocul produselor cu cele din FGO</label></th><td><label class='button fgo_update_stock'>Actualizeaza stocul</label><p>Se vor prelua produsele din FGO care au fost modificate in ultimele 7 zile. Este necesar sa existe corespondent intre codurile din magazin si codurile de articol din FGO. Aceasta functionalitate este apelabila la intervale mai mari de 30 minute.</p><p style='color:orange'><i class='dashicons dashicons-warning' style='color:orange'></i> Pentru aceasta functionalitate este necesar abonamentul Enterprise.</p> </td></tr>");
            }
          });

        $(document).on('change', $('#wc_settings_tab_fgo_client_vat_external'), function(){
            if($pluginExtern.val() == "0"){
                $vatField.closest("tr").show();
                $nrRegComField.closest("tr").show();
            }
            else if($pluginExtern.val() == '1'){
                $vatField.closest("tr").hide();
                $nrRegComField.closest("tr").hide();
            }
        });

        $(document).on('change', $('#wc_settings_tab_fgo_series_option'), function(){
            if($seriesTransmition.val() == "0"){
                $tableDifferentSeries.hide();
                $tableDifferentDesc.hide();
                $rowSingleSeries.show();
            }
            else if($seriesTransmition.val() == '1'){
                $rowSingleSeries.hide();
                $tableDifferentSeries.show();
                $tableDifferentDesc.show();
            }
        });


        $(document).on('click', '.woocommerce-fgo-check-connection', function () {

            //$('.woocommerce-fgo-check-connection').block({
            //    message: null,
            //    overlayCSS: {
            //        background: '#fff',
            //        opacity: 0.6
            //    }
            //});
            var data = {
                action: 'woocommerce_fgo_check_credentials',
            };

            $.get(woocommerce_check_fgo_premium.ajax_url, data)
                .done(function (result, textStatus) {
                    $(".woocommerce-fgo-check-connection").closest(".woocommerce-check").append("<p>" + result + "</p>")
                })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    $(".woocommerce-fgo-check-connection").closest(".woocommerce-check").append("<p class='text-danger'>Nu se poate conecta</p>")
                });
            //.always(function () {
            //    $('.woocommerce-fgo-check-connection').unblock();
            //});

        });

        $(document).on('click', '.fgo_update_stock', function () {
            if (confirm("Esti sigur ca vrei sa actualizezi stocul?") == false)
                return;

            var data = {
                action: 'woocommerce_fgo_update_stock',
                security: woocommerce_check_fgo_premium.ajax_nonce
            };

             $('.fgo_update_stock').block({
               message: null,
               overlayCSS: {
                   background: '#fff',
                   opacity: 0.6
               }
            });

            $.post(woocommerce_check_fgo_premium.ajax_url, data)
                .done(function (response) {
                    if (isJsonString(response)) {
                        var obj = JSON.parse(response);
                        if (obj.Success == false) {
                            $("#mainform").find("h2").prepend('<div class="notice notice-warning"><p>' + obj.Message + '</p></div>');
                        }
                        else if (obj.Success) {
                            $("#mainform").find("h2").html('<div class="notice notice-warning"><p>Stocul a fost actualizat.</p></div>');
                        }
                    }
                    else
                    {   
                        $("#mainform").find("h2").prepend('<div class="notice notice-error"><p>' + response + '</p></div>');
                    }
                })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    console.log("Eroare apel, parametri: ", data);
                    $("#mainform").find("h2").prepend('<div class="notice notice-error"><p>' + errorThrown + '</p></div>');
                })
                .always(function () {
                    $('.fgo_update_stock').unblock();
                });
        });

    });

    function isJsonString(str) {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    }
});