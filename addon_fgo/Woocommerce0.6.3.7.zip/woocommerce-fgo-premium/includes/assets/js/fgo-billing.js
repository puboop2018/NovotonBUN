// jQuery(function ($) {
//     $( document ).ready(function(){
//     $("#wc_order_CUI_fgo_client_field").hide();
//     $("#wc_order_NrRegComertului_fgo_client_field").hide();
    
//     $("#billing_checkbox_trigger").on("change", function(){
//         if (this.checked) {
//             $("#wc_order_CUI_fgo_client_field").show();
//             $("#wc_order_NrRegComertului_fgo_client_field").show();
//            // jQuery('#new_billing_field_field input').val('');         
//          } else {
//             $("#wc_order_CUI_fgo_client_field").hide();
//             $("#wc_order_NrRegComertului_fgo_client_field").hide();
//          }
//     })
// });
// });