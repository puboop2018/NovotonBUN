<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WC_FGO_Order_Page {

public static function init() {

add_filter( 'manage_edit-shop_order_columns','addPreviewColumn');

function addPreviewColumn($columns)
{
    $columns['previewFactura'] = 'Vizualizare/generare factura';

	return $columns;   
}	

add_action( 'manage_shop_order_posts_custom_column' , 'RenderPreviewColumn' );

// daca se foloseste optiune HPSO
add_filter( 'woocommerce_shop_order_list_table_columns','addPreviewColumn');

add_action( 'woocommerce_shop_order_list_table_custom_column', function ( $column, $order ) {
	if ( 'previewFactura' !== $column ) {
		return;
	}
    global $post;

    wp_register_script( 'fgo-script', '/wp-content/plugins/woocommerce-fgo-premium/includes/assets/js/fgo-premium-order.js', array ( 'jquery' ), 1.1, true);
	wp_register_script( 'test-script', '/wp-content/plugins/woocommerce-fgo-premium/includes/assets/js/fgo-order-page.js', array ( 'jquery' ), 1.1, true);
	wp_enqueue_script( 'fgo-script');
    wp_enqueue_script( 'test-script');
    
    $params = array(
	    'ajax_nonce' => wp_create_nonce('fgo_field_nonce'),
	    'ajax_url' => admin_url('admin-ajax.php', 'woocommerce_admin_meta_boxes_fgo_premium'),
    );
    wp_localize_script( 'test-script', 'woocommerce_admin_meta_boxes_fgo_premium', $params );


   if( $column == 'previewFactura' ) {

				$meta_invoice_link = get_post_meta( $order->get_id(), '_fgo_invoice_link', true ) ? get_post_meta( $order->get_id(), '_fgo_invoice_link', true ) : '';
				$meta_invoice_number = get_post_meta( $order->get_id(), '_fgo_invoice_number', true ) ? get_post_meta( $order->get_id(), '_fgo_invoice_number', true ) : '';
                $meta_invoice_series = get_post_meta( $order->get_id(), '_fgo_invoice_series', true ) ? get_post_meta( $order->get_id(), '_fgo_invoice_series', true ) : '';
				$meta_invoice_status = get_post_meta( $order->get_id(), '_fgo_invoice_status', true ) ? get_post_meta( $order->get_id(), '_fgo_invoice_status', true ) : '';
				
				$fgo_is_working = get_option('wc_settings_tab_fgo_is_working');

                if($fgo_is_working == '' || $fgo_is_working  == '0'){
                    echo '<p><b><font color="red">Asigura-te ca ai configurat corect setarile FGO!</font></b></p>';
                }
                else if (empty($meta_invoice_link))
				{
				    if ($meta_invoice_status == 'anulata')
                    {
                        echo '<center><div class="note_content"><p>Factura a fost anulata</p></div></center>';
                    }
                    else if ($meta_invoice_status == 'stornata')
                    {
                        echo '<center><div class="note_content"><p>Factura a fost stornata</p></div></center>';
                    }
                    else {
                        echo '<center><a href="#" class="fgo_create_invoice">Generează</a>&nbsp;<span class="fgo-loading" style="display:none;">⏳</span></center>';
                    }
				}
				else
				{                  
					echo '<center><a href="' . $meta_invoice_link . '" target="_blank">Factura ' . $meta_invoice_series . $meta_invoice_number . '</a> &nbsp;
                            <a href="#" class="fgo_cancel_invoice">Anuleaza</a> &nbsp; <a href="#" class="fgo_delete_invoice">Sterge </a>
                            &nbsp; <a href="#" class="fgo_storno_invoice">Storneaza </a>
                          </p></center<';
				}
			}
		
		}, 10, 2 );

/////

function RenderPreviewColumn( $column ) {
    global $post;

    wp_register_script( 'fgo-script', '/wp-content/plugins/woocommerce-fgo-premium/includes/assets/js/fgo-premium-order.js', array ( 'jquery' ), 1.1, true);
	wp_register_script( 'test-script', '/wp-content/plugins/woocommerce-fgo-premium/includes/assets/js/fgo-order-page.js', array ( 'jquery' ), 1.1, true);
	wp_enqueue_script( 'fgo-script');
    wp_enqueue_script( 'test-script');
    
    $params = array(
	    'ajax_nonce' => wp_create_nonce('fgo_field_nonce'),
	    'ajax_url' => admin_url('admin-ajax.php', 'woocommerce_admin_meta_boxes_fgo_premium'),
    );
    wp_localize_script( 'test-script', 'woocommerce_admin_meta_boxes_fgo_premium', $params );


   if( $column == 'previewFactura' ) {

				$meta_invoice_link = get_post_meta( $post->ID, '_fgo_invoice_link', true ) ? get_post_meta( $post->ID, '_fgo_invoice_link', true ) : '';
				$meta_invoice_number = get_post_meta( $post->ID, '_fgo_invoice_number', true ) ? get_post_meta( $post->ID, '_fgo_invoice_number', true ) : '';
                $meta_invoice_series = get_post_meta( $post->ID, '_fgo_invoice_series', true ) ? get_post_meta( $post->ID, '_fgo_invoice_series', true ) : '';
				$meta_invoice_status = get_post_meta( $post->ID, '_fgo_invoice_status', true ) ? get_post_meta( $post->ID, '_fgo_invoice_status', true ) : '';
				
				$fgo_is_working = get_option('wc_settings_tab_fgo_is_working');

                if($fgo_is_working == '' || $fgo_is_working  == '0'){
                    echo '<p><b><font color="red">Asigura-te ca ai configurat corect setarile FGO!</font></b></p>';
                }
                else if (empty($meta_invoice_link))
				{
				    if ($meta_invoice_status == 'anulata')
                    {
                        echo '<center><div class="note_content"><p>Factura a fost anulata</p></div></center>';
                    }
                    else if ($meta_invoice_status == 'stornata')
                    {
                        echo '<center><div class="note_content"><p>Factura a fost stornata</p></div></center>';
                    }
                    else {
                        echo '<center><a href="#" class="fgo_create_invoice">Generează</a>&nbsp;<span class="fgo-loading" style="display:none;">⏳</span></center>';
                    }
				}
				else
				{                  
					echo '<center><a href="' . $meta_invoice_link . '" target="_blank">Factura ' . $meta_invoice_series . $meta_invoice_number . '</a> &nbsp;
                            <a href="#" class="fgo_cancel_invoice">Anuleaza</a> &nbsp; <a href="#" class="fgo_delete_invoice">Sterge </a>
                            &nbsp; <a href="#" class="fgo_storno_invoice">Storneaza </a>
                          </p></center<';
				}
			}
		
		}
}
}