<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CONFIG {
    //constants
    public static $FGO_SANDBOX_ROOT = 'https://api-testuat.fgo.ro/v1/';
    public static $FGO_ROOT = 'https://api.fgo.ro/v1/';

    public static $FGO_VALUTA = 'RON';
    public static $FGO_TIP_FACTURA = 'Factura';
    public static $FGO_TIP_PROFORMA = 'Proforma';
    public static $FGO_TIP_AVIZ = 'Aviz';
    public static $FGO_TIP_COMANDA = 'Comanda';
    public static $FGO_UM = 'H87';
    public static $FGO_PLATFORMA = 'WooCommerce';
    public static $FGO_VERSIUNE_MODUL = '0.6.3.7';
    public static $FGO_DESC_ORDERID = 'orderId';
    public static $FGO_DESC_PAYMENT = 'payment';
    public static $FGO_DESC_SHIPPING = 'shipping';

    public static function generateHash($clientCode, $privateKey, $param) {
        return strtoupper(SHA1($clientCode . $privateKey . $param));
    }

    /*public static function logRequest($param, $data)
    {
        if ($param['wc_settings_tab_fgo_check_debug'] == '1' || $param['wc_settings_tab_fgo_check_debug'] == 'yes') {
            echo "<script>console.log(JSON.parse('" . json_encode($data) . "'));</script>";
        }
    }*/
    public static function convertDiacritics($string)
    {
        return preg_replace('/[^ \w]+/', '', iconv('UTF-8', 'ASCII//TRANSLIT', $string));
    }

    public static function is_html($string) {
        return preg_match('/<[^<]+>/', $string) !== 0;
    }

    public static function extractTextFromHtml($html) {
        // Use strip_tags to remove HTML tags
        $text = strip_tags($html);
        
        // Optionally decode HTML entities to plain text
        $decodedText = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        return trim($decodedText); // Trim whitespace from the result
    }

    public static function convertDiacritics2($string)
    {
        $a1 = array("ă", "â"); $a11= array("Ă", "Â");
        $a2 = "î";  $a21 = "Î";
        $a3 = "ș"; $a31 = "Ș";
        $a4 = array("ț","ţ"); $a41 = array("Ț", "Ţ");

        $output = str_replace($a1, "a", $string); $output = str_replace($a11, "A", $output);
		$output = str_replace($a2, "i", $output); $output = str_replace($a21, "I", $output);
		$output = str_replace($a3, "s", $output); $output = str_replace($a31, "S", $output);
		$output = str_replace($a4, "t", $output); $output = str_replace($a41, "T", $output);

        return $output;
    }
    
    public static function fgo_get_site_url()
    {
        $site_name = get_site_url();
        $atrReadonly =  array('readonly' => 'readonly');
        if($site_name === "" || $site_name === '0' || $site_name === NULL){
            if (defined( 'WP_HOME')) {
                $site_name = WP_HOME;
            }
        }

        if($site_name === "" || $site_name === '0' || $site_name === NULL){
            return '';
        }

        return $site_name;
    }

    public static function closestVATRate($vat_rate) {
        $allowed_rates = [5, 9, 11, 21];
        
        $closest_rate = null;
        $min_difference = INF;
    
        foreach ($allowed_rates as $rate) {
            $difference = abs($vat_rate - $rate);
            if ($difference < $min_difference) {
                $closest_rate = $rate;
                $min_difference = $difference;
            }
        }
    
        return $closest_rate;
    }

    public static function normalize_customer_id_for_api($customer_id) {
        $max_int32 = 2147483647;
        $id_str = (string)$customer_id;

        if (!is_numeric($id_str)) {
            $crc = crc32($id_str);
            $unsigned = intval(sprintf('%u', $crc));
            return $unsigned > $max_int32 ? $unsigned % $max_int32 : $unsigned;
        }

        $id_num = floatval($id_str);

        if ($id_num > $max_int32) {
            $crc = crc32($id_str);
            $unsigned = intval(sprintf('%u', $crc));
            return $unsigned > $max_int32 ? $unsigned % $max_int32 : $unsigned;
        }

        return intval($id_num);
    }
}